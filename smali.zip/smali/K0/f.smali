.class public abstract LK0/f;
.super LK0/e;
.source "SourceFile"
