.class public abstract LK0/g;
.super LK0/f;
.source "SourceFile"
