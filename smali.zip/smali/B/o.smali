.class public abstract LB/o;
.super Li1/a;
.source "SourceFile"
