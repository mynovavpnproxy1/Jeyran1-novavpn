.class public abstract LB/j;
.super Li1/a;
.source "SourceFile"
