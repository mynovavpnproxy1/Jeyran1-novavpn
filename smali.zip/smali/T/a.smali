.class public abstract LT/a;
.super Landroid/graphics/drawable/Drawable;
.source "SourceFile"
