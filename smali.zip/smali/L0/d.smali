.class public interface abstract LL0/d;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract g()LL0/i;
.end method

.method public abstract l(Ljava/lang/Object;)V
.end method
