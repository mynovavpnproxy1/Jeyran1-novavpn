.class public interface abstract LL0/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LL0/i;


# virtual methods
.method public abstract getKey()LL0/h;
.end method
