.class public interface abstract LL0/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LL0/g;
