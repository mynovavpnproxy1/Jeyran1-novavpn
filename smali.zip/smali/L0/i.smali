.class public interface abstract LL0/i;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract c(LL0/h;)LL0/g;
.end method

.method public abstract e(LL0/i;)LL0/i;
.end method

.method public abstract i(LL0/h;)LL0/i;
.end method

.method public abstract m(Ljava/lang/Object;LS0/p;)Ljava/lang/Object;
.end method
