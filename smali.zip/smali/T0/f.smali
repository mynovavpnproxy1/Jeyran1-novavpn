.class public interface abstract LT0/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LJ0/a;


# virtual methods
.method public abstract b()I
.end method
