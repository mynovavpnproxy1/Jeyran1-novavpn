.class public LA/N;
.super LA/M;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, LA/M;-><init>()V

    return-void
.end method

.method public constructor <init>(LA/c0;)V
    .locals 0

    .line 2
    invoke-direct {p0, p1}, LA/M;-><init>(LA/c0;)V

    return-void
.end method
