.class public interface abstract LA/m;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract b(LA/c0;)LA/c0;
.end method
