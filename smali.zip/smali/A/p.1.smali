.class public interface abstract LA/p;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(IIIZ)V
.end method

.method public abstract b(IIII)V
.end method
