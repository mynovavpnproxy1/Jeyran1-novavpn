.class public final synthetic LH0/i0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic d:LH0/j0;

.field public final synthetic e:I

.field public final synthetic f:I

.field public final synthetic g:I

.field public final synthetic h:I


# direct methods
.method public synthetic constructor <init>(LH0/j0;IIII)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LH0/i0;->d:LH0/j0;

    iput p2, p0, LH0/i0;->e:I

    iput p3, p0, LH0/i0;->f:I

    iput p4, p0, LH0/i0;->g:I

    iput p5, p0, LH0/i0;->h:I

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 15

    .line 1
    iget v0, p0, LH0/i0;->e:I

    .line 2
    .line 3
    int-to-long v0, v0

    .line 4
    iget v2, p0, LH0/i0;->f:I

    .line 5
    .line 6
    int-to-long v2, v2

    .line 7
    iget v4, p0, LH0/i0;->g:I

    .line 8
    .line 9
    int-to-long v4, v4

    .line 10
    iget v6, p0, LH0/i0;->h:I

    .line 11
    .line 12
    int-to-long v6, v6

    .line 13
    new-instance v8, LH0/r;

    .line 14
    .line 15
    const/4 v9, 0x3

    .line 16
    invoke-direct {v8, v9}, LH0/r;-><init>(I)V

    .line 17
    .line 18
    .line 19
    iget-object v9, p0, LH0/i0;->d:LH0/j0;

    .line 20
    .line 21
    iget-object v10, v9, LH0/j0;->d:LH0/k;

    .line 22
    .line 23
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    .line 25
    .line 26
    iget-object v10, v10, LH0/k;->a:LH0/P;

    .line 27
    .line 28
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 29
    .line 30
    .line 31
    iget-object v11, v10, LH0/P;->b:LH0/e;

    .line 32
    .line 33
    invoke-virtual {v11, v9}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    move-result v11

    .line 37
    if-nez v11, :cond_0

    .line 38
    .line 39
    const-string v0, ""

    .line 40
    .line 41
    const-string v1, "missing-instance-error"

    .line 42
    .line 43
    const-string v2, "Callback to `WebView.onScrollChanged` failed because native instance was not in the instance manager."

    .line 44
    .line 45
    invoke-static {v1, v2, v0}, LF0/f;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    return-void

    .line 49
    :cond_0
    invoke-virtual {v10}, LH0/P;->a()LA0/n;

    .line 50
    .line 51
    .line 52
    move-result-object v11

    .line 53
    new-instance v12, LA0/e;

    .line 54
    .line 55
    const-string v13, "dev.flutter.pigeon.webview_flutter_android.WebView.onScrollChanged"

    .line 56
    .line 57
    const/4 v14, 0x0

    .line 58
    iget-object v10, v10, LH0/P;->a:LA0/h;

    .line 59
    .line 60
    invoke-direct {v12, v10, v13, v11, v14}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 61
    .line 62
    .line 63
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 68
    .line 69
    .line 70
    move-result-object v1

    .line 71
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 72
    .line 73
    .line 74
    move-result-object v2

    .line 75
    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 76
    .line 77
    .line 78
    move-result-object v3

    .line 79
    filled-new-array {v9, v0, v1, v2, v3}, [Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    invoke-static {v0}, LK0/e;->R([Ljava/lang/Object;)Ljava/util/List;

    .line 84
    .line 85
    .line 86
    move-result-object v0

    .line 87
    new-instance v1, LA/c;

    .line 88
    .line 89
    const/16 v2, 0x16

    .line 90
    .line 91
    invoke-direct {v1, v2, v8}, LA/c;-><init>(ILjava/lang/Object;)V

    .line 92
    .line 93
    .line 94
    invoke-virtual {v12, v0, v1}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 95
    .line 96
    .line 97
    return-void
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
.end method
