.class public final synthetic LH0/r;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LS0/l;


# instance fields
.field public final synthetic d:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, LH0/r;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    const/4 v0, 0x0

    iget v1, p0, LH0/r;->d:I

    check-cast p1, LJ0/e;

    packed-switch v1, :pswitch_data_0

    sget p1, LH0/j0;->g:I

    return-object v0

    :pswitch_0
    sget p1, LH0/f0;->c:I

    return-object v0

    :pswitch_1
    sget p1, LH0/Y;->h:I

    :pswitch_2
    return-object v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
