.class public final synthetic LH0/q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic d:LH0/s;

.field public final synthetic e:Ljava/lang/String;

.field public final synthetic f:Ljava/lang/String;

.field public final synthetic g:Ljava/lang/String;

.field public final synthetic h:Ljava/lang/String;

.field public final synthetic i:J


# direct methods
.method public synthetic constructor <init>(LH0/s;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LH0/q;->d:LH0/s;

    iput-object p2, p0, LH0/q;->e:Ljava/lang/String;

    iput-object p3, p0, LH0/q;->f:Ljava/lang/String;

    iput-object p4, p0, LH0/q;->g:Ljava/lang/String;

    iput-object p5, p0, LH0/q;->h:Ljava/lang/String;

    iput-wide p6, p0, LH0/q;->i:J

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 11

    .line 1
    new-instance v0, LH0/r;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, LH0/r;-><init>(I)V

    .line 5
    .line 6
    .line 7
    iget-object v2, p0, LH0/q;->d:LH0/s;

    .line 8
    .line 9
    iget-object v1, v2, LH0/s;->a:LH0/k;

    .line 10
    .line 11
    iget-object v3, p0, LH0/q;->e:Ljava/lang/String;

    .line 12
    .line 13
    const-string v4, "urlArg"

    .line 14
    .line 15
    invoke-static {v3, v4}, LT0/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    iget-object v4, p0, LH0/q;->f:Ljava/lang/String;

    .line 19
    .line 20
    const-string v5, "userAgentArg"

    .line 21
    .line 22
    invoke-static {v4, v5}, LT0/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    iget-object v5, p0, LH0/q;->g:Ljava/lang/String;

    .line 26
    .line 27
    const-string v6, "contentDispositionArg"

    .line 28
    .line 29
    invoke-static {v5, v6}, LT0/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    iget-object v6, p0, LH0/q;->h:Ljava/lang/String;

    .line 33
    .line 34
    const-string v7, "mimetypeArg"

    .line 35
    .line 36
    invoke-static {v6, v7}, LT0/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    iget-object v1, v1, LH0/k;->a:LH0/P;

    .line 40
    .line 41
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 42
    .line 43
    .line 44
    iget-object v7, v1, LH0/P;->b:LH0/e;

    .line 45
    .line 46
    invoke-virtual {v7, v2}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    move-result v7

    .line 50
    if-nez v7, :cond_0

    .line 51
    .line 52
    const-string v0, ""

    .line 53
    .line 54
    const-string v1, "missing-instance-error"

    .line 55
    .line 56
    const-string v2, "Callback to `DownloadListener.onDownloadStart` failed because native instance was not in the instance manager."

    .line 57
    .line 58
    invoke-static {v1, v2, v0}, LF0/f;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    return-void

    .line 62
    :cond_0
    invoke-virtual {v1}, LH0/P;->a()LA0/n;

    .line 63
    .line 64
    .line 65
    move-result-object v7

    .line 66
    new-instance v8, LA0/e;

    .line 67
    .line 68
    const-string v9, "dev.flutter.pigeon.webview_flutter_android.DownloadListener.onDownloadStart"

    .line 69
    .line 70
    const/4 v10, 0x0

    .line 71
    iget-object v1, v1, LH0/P;->a:LA0/h;

    .line 72
    .line 73
    invoke-direct {v8, v1, v9, v7, v10}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 74
    .line 75
    .line 76
    iget-wide v9, p0, LH0/q;->i:J

    .line 77
    .line 78
    invoke-static {v9, v10}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 79
    .line 80
    .line 81
    move-result-object v7

    .line 82
    filled-new-array/range {v2 .. v7}, [Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object v1

    .line 86
    invoke-static {v1}, LK0/e;->R([Ljava/lang/Object;)Ljava/util/List;

    .line 87
    .line 88
    .line 89
    move-result-object v1

    .line 90
    new-instance v2, LA/c;

    .line 91
    .line 92
    const/4 v3, 0x5

    .line 93
    invoke-direct {v2, v3, v0}, LA/c;-><init>(ILjava/lang/Object;)V

    .line 94
    .line 95
    .line 96
    invoke-virtual {v8, v1, v2}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 97
    .line 98
    .line 99
    return-void
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
.end method
