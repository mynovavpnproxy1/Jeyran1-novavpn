.class public final synthetic LH0/d0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic d:LH0/f0;

.field public final synthetic e:Landroid/webkit/WebView;

.field public final synthetic f:Ljava/lang/String;

.field public final synthetic g:Z


# direct methods
.method public synthetic constructor <init>(LH0/f0;Landroid/webkit/WebView;Ljava/lang/String;Z)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LH0/d0;->d:LH0/f0;

    iput-object p2, p0, LH0/d0;->e:Landroid/webkit/WebView;

    iput-object p3, p0, LH0/d0;->f:Ljava/lang/String;

    iput-boolean p4, p0, LH0/d0;->g:Z

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 9

    .line 1
    new-instance v0, LH0/r;

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    invoke-direct {v0, v1}, LH0/r;-><init>(I)V

    .line 5
    .line 6
    .line 7
    iget-object v1, p0, LH0/d0;->d:LH0/f0;

    .line 8
    .line 9
    iget-object v2, v1, LH0/f0;->a:LH0/o;

    .line 10
    .line 11
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    iget-object v3, p0, LH0/d0;->e:Landroid/webkit/WebView;

    .line 15
    .line 16
    const-string v4, "webViewArg"

    .line 17
    .line 18
    invoke-static {v3, v4}, LT0/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    iget-object v4, p0, LH0/d0;->f:Ljava/lang/String;

    .line 22
    .line 23
    const-string v5, "urlArg"

    .line 24
    .line 25
    invoke-static {v4, v5}, LT0/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    iget-object v2, v2, LH0/o;->a:LH0/P;

    .line 29
    .line 30
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 31
    .line 32
    .line 33
    iget-object v5, v2, LH0/P;->b:LH0/e;

    .line 34
    .line 35
    invoke-virtual {v5, v1}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    move-result v5

    .line 39
    if-nez v5, :cond_0

    .line 40
    .line 41
    const-string v0, ""

    .line 42
    .line 43
    const-string v1, "missing-instance-error"

    .line 44
    .line 45
    const-string v2, "Callback to `WebViewClient.doUpdateVisitedHistory` failed because native instance was not in the instance manager."

    .line 46
    .line 47
    invoke-static {v1, v2, v0}, LF0/f;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    return-void

    .line 51
    :cond_0
    invoke-virtual {v2}, LH0/P;->a()LA0/n;

    .line 52
    .line 53
    .line 54
    move-result-object v5

    .line 55
    new-instance v6, LA0/e;

    .line 56
    .line 57
    const-string v7, "dev.flutter.pigeon.webview_flutter_android.WebViewClient.doUpdateVisitedHistory"

    .line 58
    .line 59
    const/4 v8, 0x0

    .line 60
    iget-object v2, v2, LH0/P;->a:LA0/h;

    .line 61
    .line 62
    invoke-direct {v6, v2, v7, v5, v8}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 63
    .line 64
    .line 65
    iget-boolean v2, p0, LH0/d0;->g:Z

    .line 66
    .line 67
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 68
    .line 69
    .line 70
    move-result-object v2

    .line 71
    filled-new-array {v1, v3, v4, v2}, [Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object v1

    .line 75
    invoke-static {v1}, LK0/e;->R([Ljava/lang/Object;)Ljava/util/List;

    .line 76
    .line 77
    .line 78
    move-result-object v1

    .line 79
    new-instance v2, LH0/N;

    .line 80
    .line 81
    const/4 v3, 0x6

    .line 82
    invoke-direct {v2, v3, v0}, LH0/N;-><init>(ILjava/lang/Object;)V

    .line 83
    .line 84
    .line 85
    invoke-virtual {v6, v1, v2}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 86
    .line 87
    .line 88
    return-void
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
.end method
