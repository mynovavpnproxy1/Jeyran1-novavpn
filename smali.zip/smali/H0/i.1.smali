.class public final LH0/i;
.super LH0/b;
.source "SourceFile"


# instance fields
.field public final d:LH0/P;


# direct methods
.method public constructor <init>(LH0/P;)V
    .locals 1

    .line 1
    const-string v0, "registrar"

    .line 2
    .line 3
    invoke-static {p1, v0}, LT0/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, LH0/i;->d:LH0/P;

    .line 10
    .line 11
    return-void
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
.end method

.method public static final l(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Throwable;)V
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "Failed to create new Dart proxy instance of "

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 9
    .line 10
    .line 11
    const-string p0, ": "

    .line 12
    .line 13
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 14
    .line 15
    .line 16
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 17
    .line 18
    .line 19
    const-string p0, ". "

    .line 20
    .line 21
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 22
    .line 23
    .line 24
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 25
    .line 26
    .line 27
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    const-string p1, "PigeonProxyApiBaseCodec"

    .line 32
    .line 33
    invoke-static {p1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 34
    .line 35
    .line 36
    return-void
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
.end method


# virtual methods
.method public final f(BLjava/nio/ByteBuffer;)Ljava/lang/Object;
    .locals 3

    .line 1
    const-string v0, "buffer"

    .line 2
    .line 3
    invoke-static {p2, v0}, LT0/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const/16 v0, -0x80

    .line 7
    .line 8
    if-ne p1, v0, :cond_1

    .line 9
    .line 10
    invoke-virtual {p0, p2}, LA0/t;->e(Ljava/nio/ByteBuffer;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    const-string p2, "null cannot be cast to non-null type kotlin.Long"

    .line 15
    .line 16
    invoke-static {p1, p2}, LT0/h;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    check-cast p1, Ljava/lang/Long;

    .line 20
    .line 21
    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    .line 22
    .line 23
    .line 24
    move-result-wide p1

    .line 25
    iget-object v0, p0, LH0/i;->d:LH0/P;

    .line 26
    .line 27
    iget-object v0, v0, LH0/P;->b:LH0/e;

    .line 28
    .line 29
    invoke-virtual {v0, p1, p2}, LH0/e;->e(J)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    if-nez v0, :cond_0

    .line 34
    .line 35
    new-instance v1, Ljava/lang/StringBuilder;

    .line 36
    .line 37
    const-string v2, "Failed to find instance with identifier: "

    .line 38
    .line 39
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    invoke-virtual {v1, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 43
    .line 44
    .line 45
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    const-string p2, "PigeonProxyApiBaseCodec"

    .line 50
    .line 51
    invoke-static {p2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 52
    .line 53
    .line 54
    :cond_0
    return-object v0

    .line 55
    :cond_1
    invoke-super {p0, p1, p2}, LH0/b;->f(BLjava/nio/ByteBuffer;)Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    return-object p1
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
.end method

.method public final k(LA0/s;Ljava/lang/Object;)V
    .locals 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    instance-of v3, v2, Ljava/lang/Boolean;

    .line 8
    .line 9
    if-nez v3, :cond_46

    .line 10
    .line 11
    instance-of v3, v2, [B

    .line 12
    .line 13
    if-nez v3, :cond_46

    .line 14
    .line 15
    instance-of v3, v2, Ljava/lang/Double;

    .line 16
    .line 17
    if-nez v3, :cond_46

    .line 18
    .line 19
    instance-of v3, v2, [D

    .line 20
    .line 21
    if-nez v3, :cond_46

    .line 22
    .line 23
    instance-of v3, v2, [F

    .line 24
    .line 25
    if-nez v3, :cond_46

    .line 26
    .line 27
    instance-of v3, v2, Ljava/lang/Integer;

    .line 28
    .line 29
    if-nez v3, :cond_46

    .line 30
    .line 31
    instance-of v3, v2, [I

    .line 32
    .line 33
    if-nez v3, :cond_46

    .line 34
    .line 35
    instance-of v3, v2, Ljava/util/List;

    .line 36
    .line 37
    if-nez v3, :cond_46

    .line 38
    .line 39
    instance-of v3, v2, Ljava/lang/Long;

    .line 40
    .line 41
    if-nez v3, :cond_46

    .line 42
    .line 43
    instance-of v3, v2, [J

    .line 44
    .line 45
    if-nez v3, :cond_46

    .line 46
    .line 47
    instance-of v3, v2, Ljava/util/Map;

    .line 48
    .line 49
    if-nez v3, :cond_46

    .line 50
    .line 51
    instance-of v3, v2, Ljava/lang/String;

    .line 52
    .line 53
    if-nez v3, :cond_46

    .line 54
    .line 55
    instance-of v3, v2, LH0/t;

    .line 56
    .line 57
    if-nez v3, :cond_46

    .line 58
    .line 59
    instance-of v3, v2, LH0/l;

    .line 60
    .line 61
    if-nez v3, :cond_46

    .line 62
    .line 63
    instance-of v3, v2, LH0/A;

    .line 64
    .line 65
    if-nez v3, :cond_46

    .line 66
    .line 67
    instance-of v3, v2, LH0/S;

    .line 68
    .line 69
    if-nez v3, :cond_46

    .line 70
    .line 71
    instance-of v3, v2, LH0/z;

    .line 72
    .line 73
    if-nez v3, :cond_46

    .line 74
    .line 75
    instance-of v3, v2, LH0/k0;

    .line 76
    .line 77
    if-nez v3, :cond_46

    .line 78
    .line 79
    if-nez v2, :cond_0

    .line 80
    .line 81
    goto/16 :goto_5

    .line 82
    .line 83
    :cond_0
    instance-of v3, v2, Landroid/webkit/WebResourceRequest;

    .line 84
    .line 85
    const/4 v4, 0x0

    .line 86
    iget-object v5, v0, LH0/i;->d:LH0/P;

    .line 87
    .line 88
    if-eqz v3, :cond_3

    .line 89
    .line 90
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 91
    .line 92
    .line 93
    move-object v3, v2

    .line 94
    check-cast v3, Landroid/webkit/WebResourceRequest;

    .line 95
    .line 96
    new-instance v6, LH0/h;

    .line 97
    .line 98
    const/4 v7, 0x0

    .line 99
    invoke-direct {v6, v7, v2}, LH0/h;-><init>(ILjava/lang/Object;)V

    .line 100
    .line 101
    .line 102
    iget-object v7, v5, LH0/P;->b:LH0/e;

    .line 103
    .line 104
    invoke-virtual {v7, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 105
    .line 106
    .line 107
    move-result v8

    .line 108
    if-eqz v8, :cond_1

    .line 109
    .line 110
    goto/16 :goto_4

    .line 111
    .line 112
    :cond_1
    invoke-virtual {v7, v3}, LH0/e;->b(Ljava/lang/Object;)J

    .line 113
    .line 114
    .line 115
    move-result-wide v7

    .line 116
    invoke-interface {v3}, Landroid/webkit/WebResourceRequest;->getUrl()Landroid/net/Uri;

    .line 117
    .line 118
    .line 119
    move-result-object v9

    .line 120
    invoke-virtual {v9}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 121
    .line 122
    .line 123
    move-result-object v11

    .line 124
    invoke-interface {v3}, Landroid/webkit/WebResourceRequest;->isForMainFrame()Z

    .line 125
    .line 126
    .line 127
    move-result v9

    .line 128
    invoke-interface {v3}, Landroid/webkit/WebResourceRequest;->isRedirect()Z

    .line 129
    .line 130
    .line 131
    move-result v10

    .line 132
    invoke-interface {v3}, Landroid/webkit/WebResourceRequest;->hasGesture()Z

    .line 133
    .line 134
    .line 135
    move-result v12

    .line 136
    invoke-interface {v3}, Landroid/webkit/WebResourceRequest;->getMethod()Ljava/lang/String;

    .line 137
    .line 138
    .line 139
    move-result-object v15

    .line 140
    invoke-interface {v3}, Landroid/webkit/WebResourceRequest;->getRequestHeaders()Ljava/util/Map;

    .line 141
    .line 142
    .line 143
    move-result-object v13

    .line 144
    if-nez v13, :cond_2

    .line 145
    .line 146
    sget-object v3, Ljava/util/Collections;->EMPTY_MAP:Ljava/util/Map;

    .line 147
    .line 148
    :goto_0
    move-object/from16 v16, v3

    .line 149
    .line 150
    goto :goto_1

    .line 151
    :cond_2
    invoke-interface {v3}, Landroid/webkit/WebResourceRequest;->getRequestHeaders()Ljava/util/Map;

    .line 152
    .line 153
    .line 154
    move-result-object v3

    .line 155
    goto :goto_0

    .line 156
    :goto_1
    invoke-virtual {v5}, LH0/P;->a()LA0/n;

    .line 157
    .line 158
    .line 159
    move-result-object v3

    .line 160
    new-instance v13, LA0/e;

    .line 161
    .line 162
    iget-object v14, v5, LH0/P;->a:LA0/h;

    .line 163
    .line 164
    move-wide/from16 v17, v7

    .line 165
    .line 166
    const-string v7, "dev.flutter.pigeon.webview_flutter_android.WebResourceRequest.pigeon_newInstance"

    .line 167
    .line 168
    invoke-direct {v13, v14, v7, v3, v4}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 169
    .line 170
    .line 171
    invoke-static/range {v17 .. v18}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 172
    .line 173
    .line 174
    move-result-object v3

    .line 175
    invoke-static {v9}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 176
    .line 177
    .line 178
    move-result-object v4

    .line 179
    invoke-static {v10}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 180
    .line 181
    .line 182
    move-result-object v7

    .line 183
    invoke-static {v12}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 184
    .line 185
    .line 186
    move-result-object v14

    .line 187
    move-object v10, v3

    .line 188
    move-object v12, v4

    .line 189
    move-object v3, v13

    .line 190
    move-object v13, v7

    .line 191
    filled-new-array/range {v10 .. v16}, [Ljava/lang/Object;

    .line 192
    .line 193
    .line 194
    move-result-object v4

    .line 195
    invoke-static {v4}, LK0/e;->R([Ljava/lang/Object;)Ljava/util/List;

    .line 196
    .line 197
    .line 198
    move-result-object v4

    .line 199
    new-instance v7, LG0/f;

    .line 200
    .line 201
    const/16 v8, 0x17

    .line 202
    .line 203
    invoke-direct {v7, v8, v6}, LG0/f;-><init>(ILjava/lang/Object;)V

    .line 204
    .line 205
    .line 206
    invoke-virtual {v3, v4, v7}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 207
    .line 208
    .line 209
    goto/16 :goto_4

    .line 210
    .line 211
    :cond_3
    instance-of v3, v2, Landroid/webkit/WebResourceResponse;

    .line 212
    .line 213
    if-eqz v3, :cond_5

    .line 214
    .line 215
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 216
    .line 217
    .line 218
    move-object v3, v2

    .line 219
    check-cast v3, Landroid/webkit/WebResourceResponse;

    .line 220
    .line 221
    new-instance v6, LH0/h;

    .line 222
    .line 223
    const/16 v7, 0x19

    .line 224
    .line 225
    invoke-direct {v6, v7, v2}, LH0/h;-><init>(ILjava/lang/Object;)V

    .line 226
    .line 227
    .line 228
    iget-object v7, v5, LH0/P;->b:LH0/e;

    .line 229
    .line 230
    invoke-virtual {v7, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 231
    .line 232
    .line 233
    move-result v8

    .line 234
    if-eqz v8, :cond_4

    .line 235
    .line 236
    goto/16 :goto_4

    .line 237
    .line 238
    :cond_4
    invoke-virtual {v7, v3}, LH0/e;->b(Ljava/lang/Object;)J

    .line 239
    .line 240
    .line 241
    move-result-wide v7

    .line 242
    invoke-virtual {v3}, Landroid/webkit/WebResourceResponse;->getStatusCode()I

    .line 243
    .line 244
    .line 245
    move-result v3

    .line 246
    int-to-long v9, v3

    .line 247
    invoke-virtual {v5}, LH0/P;->a()LA0/n;

    .line 248
    .line 249
    .line 250
    move-result-object v3

    .line 251
    new-instance v11, LA0/e;

    .line 252
    .line 253
    iget-object v12, v5, LH0/P;->a:LA0/h;

    .line 254
    .line 255
    const-string v13, "dev.flutter.pigeon.webview_flutter_android.WebResourceResponse.pigeon_newInstance"

    .line 256
    .line 257
    invoke-direct {v11, v12, v13, v3, v4}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 258
    .line 259
    .line 260
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 261
    .line 262
    .line 263
    move-result-object v3

    .line 264
    invoke-static {v9, v10}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 265
    .line 266
    .line 267
    move-result-object v4

    .line 268
    filled-new-array {v3, v4}, [Ljava/lang/Long;

    .line 269
    .line 270
    .line 271
    move-result-object v3

    .line 272
    invoke-static {v3}, LK0/e;->R([Ljava/lang/Object;)Ljava/util/List;

    .line 273
    .line 274
    .line 275
    move-result-object v3

    .line 276
    new-instance v4, LG0/f;

    .line 277
    .line 278
    const/16 v7, 0x18

    .line 279
    .line 280
    invoke-direct {v4, v7, v6}, LG0/f;-><init>(ILjava/lang/Object;)V

    .line 281
    .line 282
    .line 283
    invoke-virtual {v11, v3, v4}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 284
    .line 285
    .line 286
    goto/16 :goto_4

    .line 287
    .line 288
    :cond_5
    instance-of v3, v2, Landroid/webkit/WebResourceError;

    .line 289
    .line 290
    if-eqz v3, :cond_7

    .line 291
    .line 292
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 293
    .line 294
    .line 295
    move-object v3, v2

    .line 296
    check-cast v3, Landroid/webkit/WebResourceError;

    .line 297
    .line 298
    new-instance v6, LH0/h;

    .line 299
    .line 300
    const/16 v7, 0xc

    .line 301
    .line 302
    invoke-direct {v6, v7, v2}, LH0/h;-><init>(ILjava/lang/Object;)V

    .line 303
    .line 304
    .line 305
    iget-object v7, v5, LH0/P;->b:LH0/e;

    .line 306
    .line 307
    invoke-virtual {v7, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 308
    .line 309
    .line 310
    move-result v8

    .line 311
    if-eqz v8, :cond_6

    .line 312
    .line 313
    goto/16 :goto_4

    .line 314
    .line 315
    :cond_6
    invoke-virtual {v7, v3}, LH0/e;->b(Ljava/lang/Object;)J

    .line 316
    .line 317
    .line 318
    move-result-wide v7

    .line 319
    invoke-virtual {v3}, Landroid/webkit/WebResourceError;->getErrorCode()I

    .line 320
    .line 321
    .line 322
    move-result v9

    .line 323
    int-to-long v9, v9

    .line 324
    invoke-virtual {v3}, Landroid/webkit/WebResourceError;->getDescription()Ljava/lang/CharSequence;

    .line 325
    .line 326
    .line 327
    move-result-object v3

    .line 328
    invoke-interface {v3}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    .line 329
    .line 330
    .line 331
    move-result-object v3

    .line 332
    invoke-virtual {v5}, LH0/P;->a()LA0/n;

    .line 333
    .line 334
    .line 335
    move-result-object v11

    .line 336
    new-instance v12, LA0/e;

    .line 337
    .line 338
    iget-object v13, v5, LH0/P;->a:LA0/h;

    .line 339
    .line 340
    const-string v14, "dev.flutter.pigeon.webview_flutter_android.WebResourceError.pigeon_newInstance"

    .line 341
    .line 342
    invoke-direct {v12, v13, v14, v11, v4}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 343
    .line 344
    .line 345
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 346
    .line 347
    .line 348
    move-result-object v4

    .line 349
    invoke-static {v9, v10}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 350
    .line 351
    .line 352
    move-result-object v7

    .line 353
    filled-new-array {v4, v7, v3}, [Ljava/lang/Object;

    .line 354
    .line 355
    .line 356
    move-result-object v3

    .line 357
    invoke-static {v3}, LK0/e;->R([Ljava/lang/Object;)Ljava/util/List;

    .line 358
    .line 359
    .line 360
    move-result-object v3

    .line 361
    new-instance v4, LG0/f;

    .line 362
    .line 363
    const/16 v7, 0x16

    .line 364
    .line 365
    invoke-direct {v4, v7, v6}, LG0/f;-><init>(ILjava/lang/Object;)V

    .line 366
    .line 367
    .line 368
    invoke-virtual {v12, v3, v4}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 369
    .line 370
    .line 371
    goto/16 :goto_4

    .line 372
    .line 373
    :cond_7
    instance-of v3, v2, LH0/h0;

    .line 374
    .line 375
    if-eqz v3, :cond_9

    .line 376
    .line 377
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 378
    .line 379
    .line 380
    move-object v3, v2

    .line 381
    check-cast v3, LH0/h0;

    .line 382
    .line 383
    new-instance v6, LH0/h;

    .line 384
    .line 385
    const/16 v7, 0xd

    .line 386
    .line 387
    invoke-direct {v6, v7, v2}, LH0/h;-><init>(ILjava/lang/Object;)V

    .line 388
    .line 389
    .line 390
    iget-object v7, v5, LH0/P;->b:LH0/e;

    .line 391
    .line 392
    invoke-virtual {v7, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 393
    .line 394
    .line 395
    move-result v8

    .line 396
    if-eqz v8, :cond_8

    .line 397
    .line 398
    goto/16 :goto_4

    .line 399
    .line 400
    :cond_8
    invoke-virtual {v7, v3}, LH0/e;->b(Ljava/lang/Object;)J

    .line 401
    .line 402
    .line 403
    move-result-wide v7

    .line 404
    invoke-virtual {v5}, LH0/P;->a()LA0/n;

    .line 405
    .line 406
    .line 407
    move-result-object v9

    .line 408
    new-instance v10, LA0/e;

    .line 409
    .line 410
    iget-object v11, v5, LH0/P;->a:LA0/h;

    .line 411
    .line 412
    const-string v12, "dev.flutter.pigeon.webview_flutter_android.WebViewPoint.pigeon_newInstance"

    .line 413
    .line 414
    invoke-direct {v10, v11, v12, v9, v4}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 415
    .line 416
    .line 417
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 418
    .line 419
    .line 420
    move-result-object v4

    .line 421
    iget-wide v7, v3, LH0/h0;->a:J

    .line 422
    .line 423
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 424
    .line 425
    .line 426
    move-result-object v7

    .line 427
    iget-wide v8, v3, LH0/h0;->b:J

    .line 428
    .line 429
    invoke-static {v8, v9}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 430
    .line 431
    .line 432
    move-result-object v3

    .line 433
    filled-new-array {v4, v7, v3}, [Ljava/lang/Long;

    .line 434
    .line 435
    .line 436
    move-result-object v3

    .line 437
    invoke-static {v3}, LK0/e;->R([Ljava/lang/Object;)Ljava/util/List;

    .line 438
    .line 439
    .line 440
    move-result-object v3

    .line 441
    new-instance v4, LH0/O;

    .line 442
    .line 443
    const/4 v7, 0x1

    .line 444
    invoke-direct {v4, v7, v6}, LH0/O;-><init>(ILjava/lang/Object;)V

    .line 445
    .line 446
    .line 447
    invoke-virtual {v10, v3, v4}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 448
    .line 449
    .line 450
    goto/16 :goto_4

    .line 451
    .line 452
    :cond_9
    instance-of v3, v2, Landroid/webkit/ConsoleMessage;

    .line 453
    .line 454
    const/4 v6, 0x3

    .line 455
    const/4 v7, 0x1

    .line 456
    if-eqz v3, :cond_10

    .line 457
    .line 458
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 459
    .line 460
    .line 461
    move-object v3, v2

    .line 462
    check-cast v3, Landroid/webkit/ConsoleMessage;

    .line 463
    .line 464
    new-instance v8, LH0/h;

    .line 465
    .line 466
    const/16 v9, 0xe

    .line 467
    .line 468
    invoke-direct {v8, v9, v2}, LH0/h;-><init>(ILjava/lang/Object;)V

    .line 469
    .line 470
    .line 471
    iget-object v9, v5, LH0/P;->b:LH0/e;

    .line 472
    .line 473
    invoke-virtual {v9, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 474
    .line 475
    .line 476
    move-result v10

    .line 477
    if-eqz v10, :cond_a

    .line 478
    .line 479
    goto/16 :goto_4

    .line 480
    .line 481
    :cond_a
    invoke-virtual {v9, v3}, LH0/e;->b(Ljava/lang/Object;)J

    .line 482
    .line 483
    .line 484
    move-result-wide v9

    .line 485
    invoke-virtual {v3}, Landroid/webkit/ConsoleMessage;->lineNumber()I

    .line 486
    .line 487
    .line 488
    move-result v11

    .line 489
    int-to-long v11, v11

    .line 490
    invoke-virtual {v3}, Landroid/webkit/ConsoleMessage;->message()Ljava/lang/String;

    .line 491
    .line 492
    .line 493
    move-result-object v13

    .line 494
    sget-object v14, LH0/m;->a:[I

    .line 495
    .line 496
    invoke-virtual {v3}, Landroid/webkit/ConsoleMessage;->messageLevel()Landroid/webkit/ConsoleMessage$MessageLevel;

    .line 497
    .line 498
    .line 499
    move-result-object v15

    .line 500
    invoke-virtual {v15}, Ljava/lang/Enum;->ordinal()I

    .line 501
    .line 502
    .line 503
    move-result v15

    .line 504
    aget v14, v14, v15

    .line 505
    .line 506
    if-eq v14, v7, :cond_f

    .line 507
    .line 508
    const/4 v7, 0x2

    .line 509
    if-eq v14, v7, :cond_e

    .line 510
    .line 511
    if-eq v14, v6, :cond_d

    .line 512
    .line 513
    const/4 v6, 0x4

    .line 514
    if-eq v14, v6, :cond_c

    .line 515
    .line 516
    const/4 v6, 0x5

    .line 517
    if-eq v14, v6, :cond_b

    .line 518
    .line 519
    sget-object v6, LH0/l;->k:LH0/l;

    .line 520
    .line 521
    goto :goto_2

    .line 522
    :cond_b
    sget-object v6, LH0/l;->f:LH0/l;

    .line 523
    .line 524
    goto :goto_2

    .line 525
    :cond_c
    sget-object v6, LH0/l;->g:LH0/l;

    .line 526
    .line 527
    goto :goto_2

    .line 528
    :cond_d
    sget-object v6, LH0/l;->j:LH0/l;

    .line 529
    .line 530
    goto :goto_2

    .line 531
    :cond_e
    sget-object v6, LH0/l;->h:LH0/l;

    .line 532
    .line 533
    goto :goto_2

    .line 534
    :cond_f
    sget-object v6, LH0/l;->i:LH0/l;

    .line 535
    .line 536
    :goto_2
    invoke-virtual {v3}, Landroid/webkit/ConsoleMessage;->sourceId()Ljava/lang/String;

    .line 537
    .line 538
    .line 539
    move-result-object v3

    .line 540
    invoke-virtual {v5}, LH0/P;->a()LA0/n;

    .line 541
    .line 542
    .line 543
    move-result-object v7

    .line 544
    new-instance v14, LA0/e;

    .line 545
    .line 546
    iget-object v15, v5, LH0/P;->a:LA0/h;

    .line 547
    .line 548
    move-wide/from16 v16, v9

    .line 549
    .line 550
    const-string v9, "dev.flutter.pigeon.webview_flutter_android.ConsoleMessage.pigeon_newInstance"

    .line 551
    .line 552
    invoke-direct {v14, v15, v9, v7, v4}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 553
    .line 554
    .line 555
    invoke-static/range {v16 .. v17}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 556
    .line 557
    .line 558
    move-result-object v4

    .line 559
    invoke-static {v11, v12}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 560
    .line 561
    .line 562
    move-result-object v7

    .line 563
    filled-new-array {v4, v7, v13, v6, v3}, [Ljava/lang/Object;

    .line 564
    .line 565
    .line 566
    move-result-object v3

    .line 567
    invoke-static {v3}, LK0/e;->R([Ljava/lang/Object;)Ljava/util/List;

    .line 568
    .line 569
    .line 570
    move-result-object v3

    .line 571
    new-instance v4, LG0/f;

    .line 572
    .line 573
    const/4 v6, 0x5

    .line 574
    invoke-direct {v4, v6, v8}, LG0/f;-><init>(ILjava/lang/Object;)V

    .line 575
    .line 576
    .line 577
    invoke-virtual {v14, v3, v4}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 578
    .line 579
    .line 580
    goto/16 :goto_4

    .line 581
    .line 582
    :cond_10
    instance-of v3, v2, Landroid/webkit/CookieManager;

    .line 583
    .line 584
    if-eqz v3, :cond_12

    .line 585
    .line 586
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 587
    .line 588
    .line 589
    move-object v3, v2

    .line 590
    check-cast v3, Landroid/webkit/CookieManager;

    .line 591
    .line 592
    new-instance v6, LH0/h;

    .line 593
    .line 594
    const/16 v7, 0xf

    .line 595
    .line 596
    invoke-direct {v6, v7, v2}, LH0/h;-><init>(ILjava/lang/Object;)V

    .line 597
    .line 598
    .line 599
    iget-object v7, v5, LH0/P;->b:LH0/e;

    .line 600
    .line 601
    invoke-virtual {v7, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 602
    .line 603
    .line 604
    move-result v8

    .line 605
    if-eqz v8, :cond_11

    .line 606
    .line 607
    goto/16 :goto_4

    .line 608
    .line 609
    :cond_11
    invoke-virtual {v7, v3}, LH0/e;->b(Ljava/lang/Object;)J

    .line 610
    .line 611
    .line 612
    move-result-wide v7

    .line 613
    invoke-virtual {v5}, LH0/P;->a()LA0/n;

    .line 614
    .line 615
    .line 616
    move-result-object v3

    .line 617
    new-instance v9, LA0/e;

    .line 618
    .line 619
    iget-object v10, v5, LH0/P;->a:LA0/h;

    .line 620
    .line 621
    const-string v11, "dev.flutter.pigeon.webview_flutter_android.CookieManager.pigeon_newInstance"

    .line 622
    .line 623
    invoke-direct {v9, v10, v11, v3, v4}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 624
    .line 625
    .line 626
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 627
    .line 628
    .line 629
    move-result-object v3

    .line 630
    invoke-static {v3}, Li1/a;->u(Ljava/lang/Object;)Ljava/util/List;

    .line 631
    .line 632
    .line 633
    move-result-object v3

    .line 634
    new-instance v4, LG0/f;

    .line 635
    .line 636
    const/4 v7, 0x6

    .line 637
    invoke-direct {v4, v7, v6}, LG0/f;-><init>(ILjava/lang/Object;)V

    .line 638
    .line 639
    .line 640
    invoke-virtual {v9, v3, v4}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 641
    .line 642
    .line 643
    goto/16 :goto_4

    .line 644
    .line 645
    :cond_12
    instance-of v3, v2, Landroid/webkit/WebView;

    .line 646
    .line 647
    if-eqz v3, :cond_14

    .line 648
    .line 649
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 650
    .line 651
    .line 652
    move-object v3, v2

    .line 653
    check-cast v3, Landroid/webkit/WebView;

    .line 654
    .line 655
    new-instance v6, LH0/h;

    .line 656
    .line 657
    const/16 v7, 0x10

    .line 658
    .line 659
    invoke-direct {v6, v7, v2}, LH0/h;-><init>(ILjava/lang/Object;)V

    .line 660
    .line 661
    .line 662
    iget-object v7, v5, LH0/P;->b:LH0/e;

    .line 663
    .line 664
    invoke-virtual {v7, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 665
    .line 666
    .line 667
    move-result v8

    .line 668
    if-eqz v8, :cond_13

    .line 669
    .line 670
    goto/16 :goto_4

    .line 671
    .line 672
    :cond_13
    invoke-virtual {v7, v3}, LH0/e;->b(Ljava/lang/Object;)J

    .line 673
    .line 674
    .line 675
    move-result-wide v7

    .line 676
    invoke-virtual {v5}, LH0/P;->a()LA0/n;

    .line 677
    .line 678
    .line 679
    move-result-object v3

    .line 680
    new-instance v9, LA0/e;

    .line 681
    .line 682
    iget-object v10, v5, LH0/P;->a:LA0/h;

    .line 683
    .line 684
    const-string v11, "dev.flutter.pigeon.webview_flutter_android.WebView.pigeon_newInstance"

    .line 685
    .line 686
    invoke-direct {v9, v10, v11, v3, v4}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 687
    .line 688
    .line 689
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 690
    .line 691
    .line 692
    move-result-object v3

    .line 693
    invoke-static {v3}, Li1/a;->u(Ljava/lang/Object;)Ljava/util/List;

    .line 694
    .line 695
    .line 696
    move-result-object v3

    .line 697
    new-instance v4, LG0/f;

    .line 698
    .line 699
    const/16 v7, 0x1c

    .line 700
    .line 701
    invoke-direct {v4, v7, v6}, LG0/f;-><init>(ILjava/lang/Object;)V

    .line 702
    .line 703
    .line 704
    invoke-virtual {v9, v3, v4}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 705
    .line 706
    .line 707
    goto/16 :goto_4

    .line 708
    .line 709
    :cond_14
    instance-of v3, v2, Landroid/webkit/WebSettings;

    .line 710
    .line 711
    if-eqz v3, :cond_16

    .line 712
    .line 713
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 714
    .line 715
    .line 716
    move-object v3, v2

    .line 717
    check-cast v3, Landroid/webkit/WebSettings;

    .line 718
    .line 719
    new-instance v6, LH0/h;

    .line 720
    .line 721
    const/16 v7, 0x11

    .line 722
    .line 723
    invoke-direct {v6, v7, v2}, LH0/h;-><init>(ILjava/lang/Object;)V

    .line 724
    .line 725
    .line 726
    iget-object v7, v5, LH0/P;->b:LH0/e;

    .line 727
    .line 728
    invoke-virtual {v7, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 729
    .line 730
    .line 731
    move-result v8

    .line 732
    if-eqz v8, :cond_15

    .line 733
    .line 734
    goto/16 :goto_4

    .line 735
    .line 736
    :cond_15
    invoke-virtual {v7, v3}, LH0/e;->b(Ljava/lang/Object;)J

    .line 737
    .line 738
    .line 739
    move-result-wide v7

    .line 740
    invoke-virtual {v5}, LH0/P;->a()LA0/n;

    .line 741
    .line 742
    .line 743
    move-result-object v3

    .line 744
    new-instance v9, LA0/e;

    .line 745
    .line 746
    iget-object v10, v5, LH0/P;->a:LA0/h;

    .line 747
    .line 748
    const-string v11, "dev.flutter.pigeon.webview_flutter_android.WebSettings.pigeon_newInstance"

    .line 749
    .line 750
    invoke-direct {v9, v10, v11, v3, v4}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 751
    .line 752
    .line 753
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 754
    .line 755
    .line 756
    move-result-object v3

    .line 757
    invoke-static {v3}, Li1/a;->u(Ljava/lang/Object;)Ljava/util/List;

    .line 758
    .line 759
    .line 760
    move-result-object v3

    .line 761
    new-instance v4, LG0/f;

    .line 762
    .line 763
    const/16 v7, 0x19

    .line 764
    .line 765
    invoke-direct {v4, v7, v6}, LG0/f;-><init>(ILjava/lang/Object;)V

    .line 766
    .line 767
    .line 768
    invoke-virtual {v9, v3, v4}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 769
    .line 770
    .line 771
    goto/16 :goto_4

    .line 772
    .line 773
    :cond_16
    instance-of v3, v2, LH0/y;

    .line 774
    .line 775
    const-string v8, "new-instance-error"

    .line 776
    .line 777
    const-string v9, ""

    .line 778
    .line 779
    if-eqz v3, :cond_18

    .line 780
    .line 781
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 782
    .line 783
    .line 784
    move-object v3, v2

    .line 785
    check-cast v3, LH0/y;

    .line 786
    .line 787
    iget-object v4, v5, LH0/P;->b:LH0/e;

    .line 788
    .line 789
    invoke-virtual {v4, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 790
    .line 791
    .line 792
    move-result v3

    .line 793
    const-string v4, "JavaScriptChannel"

    .line 794
    .line 795
    if-eqz v3, :cond_17

    .line 796
    .line 797
    goto/16 :goto_4

    .line 798
    .line 799
    :cond_17
    new-instance v3, LH0/a;

    .line 800
    .line 801
    const-string v6, "Attempting to create a new Dart instance of JavaScriptChannel, but the class has a nonnull callback method."

    .line 802
    .line 803
    invoke-direct {v3, v8, v6, v9}, LH0/a;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 804
    .line 805
    .line 806
    invoke-static {v3}, Li1/a;->i(Ljava/lang/Throwable;)LJ0/d;

    .line 807
    .line 808
    .line 809
    move-result-object v3

    .line 810
    invoke-static {v3}, LJ0/e;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 811
    .line 812
    .line 813
    move-result-object v3

    .line 814
    invoke-static {v4, v2, v3}, LH0/i;->l(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Throwable;)V

    .line 815
    .line 816
    .line 817
    goto/16 :goto_4

    .line 818
    .line 819
    :cond_18
    instance-of v3, v2, Landroid/webkit/WebViewClient;

    .line 820
    .line 821
    if-eqz v3, :cond_1a

    .line 822
    .line 823
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 824
    .line 825
    .line 826
    move-object v3, v2

    .line 827
    check-cast v3, Landroid/webkit/WebViewClient;

    .line 828
    .line 829
    new-instance v6, LH0/h;

    .line 830
    .line 831
    const/16 v7, 0xb

    .line 832
    .line 833
    invoke-direct {v6, v7, v2}, LH0/h;-><init>(ILjava/lang/Object;)V

    .line 834
    .line 835
    .line 836
    iget-object v7, v5, LH0/P;->b:LH0/e;

    .line 837
    .line 838
    invoke-virtual {v7, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 839
    .line 840
    .line 841
    move-result v8

    .line 842
    if-eqz v8, :cond_19

    .line 843
    .line 844
    goto/16 :goto_4

    .line 845
    .line 846
    :cond_19
    invoke-virtual {v7, v3}, LH0/e;->b(Ljava/lang/Object;)J

    .line 847
    .line 848
    .line 849
    move-result-wide v7

    .line 850
    invoke-virtual {v5}, LH0/P;->a()LA0/n;

    .line 851
    .line 852
    .line 853
    move-result-object v3

    .line 854
    new-instance v9, LA0/e;

    .line 855
    .line 856
    iget-object v10, v5, LH0/P;->a:LA0/h;

    .line 857
    .line 858
    const-string v11, "dev.flutter.pigeon.webview_flutter_android.WebViewClient.pigeon_newInstance"

    .line 859
    .line 860
    invoke-direct {v9, v10, v11, v3, v4}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 861
    .line 862
    .line 863
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 864
    .line 865
    .line 866
    move-result-object v3

    .line 867
    invoke-static {v3}, Li1/a;->u(Ljava/lang/Object;)Ljava/util/List;

    .line 868
    .line 869
    .line 870
    move-result-object v3

    .line 871
    new-instance v4, LG0/f;

    .line 872
    .line 873
    const/16 v7, 0x1d

    .line 874
    .line 875
    invoke-direct {v4, v7, v6}, LG0/f;-><init>(ILjava/lang/Object;)V

    .line 876
    .line 877
    .line 878
    invoke-virtual {v9, v3, v4}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 879
    .line 880
    .line 881
    goto/16 :goto_4

    .line 882
    .line 883
    :cond_1a
    instance-of v3, v2, Landroid/webkit/DownloadListener;

    .line 884
    .line 885
    if-eqz v3, :cond_1c

    .line 886
    .line 887
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 888
    .line 889
    .line 890
    move-object v3, v2

    .line 891
    check-cast v3, Landroid/webkit/DownloadListener;

    .line 892
    .line 893
    iget-object v4, v5, LH0/P;->b:LH0/e;

    .line 894
    .line 895
    invoke-virtual {v4, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 896
    .line 897
    .line 898
    move-result v3

    .line 899
    const-string v4, "DownloadListener"

    .line 900
    .line 901
    if-eqz v3, :cond_1b

    .line 902
    .line 903
    goto/16 :goto_4

    .line 904
    .line 905
    :cond_1b
    new-instance v3, LH0/a;

    .line 906
    .line 907
    const-string v6, "Attempting to create a new Dart instance of DownloadListener, but the class has a nonnull callback method."

    .line 908
    .line 909
    invoke-direct {v3, v8, v6, v9}, LH0/a;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 910
    .line 911
    .line 912
    invoke-static {v3}, Li1/a;->i(Ljava/lang/Throwable;)LJ0/d;

    .line 913
    .line 914
    .line 915
    move-result-object v3

    .line 916
    invoke-static {v3}, LJ0/e;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 917
    .line 918
    .line 919
    move-result-object v3

    .line 920
    invoke-static {v4, v2, v3}, LH0/i;->l(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Throwable;)V

    .line 921
    .line 922
    .line 923
    goto/16 :goto_4

    .line 924
    .line 925
    :cond_1c
    instance-of v3, v2, LH0/Y;

    .line 926
    .line 927
    if-eqz v3, :cond_1e

    .line 928
    .line 929
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 930
    .line 931
    .line 932
    move-object v3, v2

    .line 933
    check-cast v3, LH0/Y;

    .line 934
    .line 935
    iget-object v4, v5, LH0/P;->b:LH0/e;

    .line 936
    .line 937
    invoke-virtual {v4, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 938
    .line 939
    .line 940
    move-result v3

    .line 941
    const-string v4, "WebChromeClient"

    .line 942
    .line 943
    if-eqz v3, :cond_1d

    .line 944
    .line 945
    goto/16 :goto_4

    .line 946
    .line 947
    :cond_1d
    new-instance v3, LH0/a;

    .line 948
    .line 949
    const-string v6, "Attempting to create a new Dart instance of WebChromeClient, but the class has a nonnull callback method."

    .line 950
    .line 951
    invoke-direct {v3, v8, v6, v9}, LH0/a;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 952
    .line 953
    .line 954
    invoke-static {v3}, Li1/a;->i(Ljava/lang/Throwable;)LJ0/d;

    .line 955
    .line 956
    .line 957
    move-result-object v3

    .line 958
    invoke-static {v3}, LJ0/e;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 959
    .line 960
    .line 961
    move-result-object v3

    .line 962
    invoke-static {v4, v2, v3}, LH0/i;->l(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Throwable;)V

    .line 963
    .line 964
    .line 965
    goto/16 :goto_4

    .line 966
    .line 967
    :cond_1e
    instance-of v3, v2, LH0/u;

    .line 968
    .line 969
    if-eqz v3, :cond_20

    .line 970
    .line 971
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 972
    .line 973
    .line 974
    move-object v3, v2

    .line 975
    check-cast v3, LH0/u;

    .line 976
    .line 977
    new-instance v6, LH0/h;

    .line 978
    .line 979
    const/16 v7, 0x12

    .line 980
    .line 981
    invoke-direct {v6, v7, v2}, LH0/h;-><init>(ILjava/lang/Object;)V

    .line 982
    .line 983
    .line 984
    iget-object v7, v5, LH0/P;->b:LH0/e;

    .line 985
    .line 986
    invoke-virtual {v7, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 987
    .line 988
    .line 989
    move-result v8

    .line 990
    if-eqz v8, :cond_1f

    .line 991
    .line 992
    goto/16 :goto_4

    .line 993
    .line 994
    :cond_1f
    invoke-virtual {v7, v3}, LH0/e;->b(Ljava/lang/Object;)J

    .line 995
    .line 996
    .line 997
    move-result-wide v7

    .line 998
    invoke-virtual {v5}, LH0/P;->a()LA0/n;

    .line 999
    .line 1000
    .line 1001
    move-result-object v3

    .line 1002
    new-instance v9, LA0/e;

    .line 1003
    .line 1004
    iget-object v10, v5, LH0/P;->a:LA0/h;

    .line 1005
    .line 1006
    const-string v11, "dev.flutter.pigeon.webview_flutter_android.FlutterAssetManager.pigeon_newInstance"

    .line 1007
    .line 1008
    invoke-direct {v9, v10, v11, v3, v4}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 1009
    .line 1010
    .line 1011
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 1012
    .line 1013
    .line 1014
    move-result-object v3

    .line 1015
    invoke-static {v3}, Li1/a;->u(Ljava/lang/Object;)Ljava/util/List;

    .line 1016
    .line 1017
    .line 1018
    move-result-object v3

    .line 1019
    new-instance v4, LG0/f;

    .line 1020
    .line 1021
    const/16 v7, 0xa

    .line 1022
    .line 1023
    invoke-direct {v4, v7, v6}, LG0/f;-><init>(ILjava/lang/Object;)V

    .line 1024
    .line 1025
    .line 1026
    invoke-virtual {v9, v3, v4}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 1027
    .line 1028
    .line 1029
    goto/16 :goto_4

    .line 1030
    .line 1031
    :cond_20
    instance-of v3, v2, Landroid/webkit/WebStorage;

    .line 1032
    .line 1033
    if-eqz v3, :cond_22

    .line 1034
    .line 1035
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1036
    .line 1037
    .line 1038
    move-object v3, v2

    .line 1039
    check-cast v3, Landroid/webkit/WebStorage;

    .line 1040
    .line 1041
    new-instance v6, LH0/h;

    .line 1042
    .line 1043
    const/16 v7, 0x13

    .line 1044
    .line 1045
    invoke-direct {v6, v7, v2}, LH0/h;-><init>(ILjava/lang/Object;)V

    .line 1046
    .line 1047
    .line 1048
    iget-object v7, v5, LH0/P;->b:LH0/e;

    .line 1049
    .line 1050
    invoke-virtual {v7, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 1051
    .line 1052
    .line 1053
    move-result v8

    .line 1054
    if-eqz v8, :cond_21

    .line 1055
    .line 1056
    goto/16 :goto_4

    .line 1057
    .line 1058
    :cond_21
    invoke-virtual {v7, v3}, LH0/e;->b(Ljava/lang/Object;)J

    .line 1059
    .line 1060
    .line 1061
    move-result-wide v7

    .line 1062
    invoke-virtual {v5}, LH0/P;->a()LA0/n;

    .line 1063
    .line 1064
    .line 1065
    move-result-object v3

    .line 1066
    new-instance v9, LA0/e;

    .line 1067
    .line 1068
    iget-object v10, v5, LH0/P;->a:LA0/h;

    .line 1069
    .line 1070
    const-string v11, "dev.flutter.pigeon.webview_flutter_android.WebStorage.pigeon_newInstance"

    .line 1071
    .line 1072
    invoke-direct {v9, v10, v11, v3, v4}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 1073
    .line 1074
    .line 1075
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 1076
    .line 1077
    .line 1078
    move-result-object v3

    .line 1079
    invoke-static {v3}, Li1/a;->u(Ljava/lang/Object;)Ljava/util/List;

    .line 1080
    .line 1081
    .line 1082
    move-result-object v3

    .line 1083
    new-instance v4, LG0/f;

    .line 1084
    .line 1085
    const/16 v7, 0x1a

    .line 1086
    .line 1087
    invoke-direct {v4, v7, v6}, LG0/f;-><init>(ILjava/lang/Object;)V

    .line 1088
    .line 1089
    .line 1090
    invoke-virtual {v9, v3, v4}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 1091
    .line 1092
    .line 1093
    goto/16 :goto_4

    .line 1094
    .line 1095
    :cond_22
    instance-of v3, v2, Landroid/webkit/WebChromeClient$FileChooserParams;

    .line 1096
    .line 1097
    if-eqz v3, :cond_27

    .line 1098
    .line 1099
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1100
    .line 1101
    .line 1102
    move-object v3, v2

    .line 1103
    check-cast v3, Landroid/webkit/WebChromeClient$FileChooserParams;

    .line 1104
    .line 1105
    new-instance v8, LH0/h;

    .line 1106
    .line 1107
    const/16 v9, 0x14

    .line 1108
    .line 1109
    invoke-direct {v8, v9, v2}, LH0/h;-><init>(ILjava/lang/Object;)V

    .line 1110
    .line 1111
    .line 1112
    iget-object v9, v5, LH0/P;->b:LH0/e;

    .line 1113
    .line 1114
    invoke-virtual {v9, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 1115
    .line 1116
    .line 1117
    move-result v10

    .line 1118
    if-eqz v10, :cond_23

    .line 1119
    .line 1120
    goto/16 :goto_4

    .line 1121
    .line 1122
    :cond_23
    invoke-virtual {v9, v3}, LH0/e;->b(Ljava/lang/Object;)J

    .line 1123
    .line 1124
    .line 1125
    move-result-wide v9

    .line 1126
    invoke-virtual {v3}, Landroid/webkit/WebChromeClient$FileChooserParams;->isCaptureEnabled()Z

    .line 1127
    .line 1128
    .line 1129
    move-result v11

    .line 1130
    invoke-virtual {v3}, Landroid/webkit/WebChromeClient$FileChooserParams;->getAcceptTypes()[Ljava/lang/String;

    .line 1131
    .line 1132
    .line 1133
    move-result-object v12

    .line 1134
    invoke-static {v12}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 1135
    .line 1136
    .line 1137
    move-result-object v12

    .line 1138
    invoke-virtual {v3}, Landroid/webkit/WebChromeClient$FileChooserParams;->getMode()I

    .line 1139
    .line 1140
    .line 1141
    move-result v13

    .line 1142
    if-eqz v13, :cond_26

    .line 1143
    .line 1144
    if-eq v13, v7, :cond_25

    .line 1145
    .line 1146
    if-eq v13, v6, :cond_24

    .line 1147
    .line 1148
    sget-object v6, LH0/t;->i:LH0/t;

    .line 1149
    .line 1150
    goto :goto_3

    .line 1151
    :cond_24
    sget-object v6, LH0/t;->h:LH0/t;

    .line 1152
    .line 1153
    goto :goto_3

    .line 1154
    :cond_25
    sget-object v6, LH0/t;->g:LH0/t;

    .line 1155
    .line 1156
    goto :goto_3

    .line 1157
    :cond_26
    sget-object v6, LH0/t;->f:LH0/t;

    .line 1158
    .line 1159
    :goto_3
    invoke-virtual {v3}, Landroid/webkit/WebChromeClient$FileChooserParams;->getFilenameHint()Ljava/lang/String;

    .line 1160
    .line 1161
    .line 1162
    move-result-object v3

    .line 1163
    invoke-virtual {v5}, LH0/P;->a()LA0/n;

    .line 1164
    .line 1165
    .line 1166
    move-result-object v7

    .line 1167
    new-instance v13, LA0/e;

    .line 1168
    .line 1169
    iget-object v14, v5, LH0/P;->a:LA0/h;

    .line 1170
    .line 1171
    const-string v15, "dev.flutter.pigeon.webview_flutter_android.FileChooserParams.pigeon_newInstance"

    .line 1172
    .line 1173
    invoke-direct {v13, v14, v15, v7, v4}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 1174
    .line 1175
    .line 1176
    invoke-static {v9, v10}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 1177
    .line 1178
    .line 1179
    move-result-object v4

    .line 1180
    invoke-static {v11}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 1181
    .line 1182
    .line 1183
    move-result-object v7

    .line 1184
    filled-new-array {v4, v7, v12, v6, v3}, [Ljava/lang/Object;

    .line 1185
    .line 1186
    .line 1187
    move-result-object v3

    .line 1188
    invoke-static {v3}, LK0/e;->R([Ljava/lang/Object;)Ljava/util/List;

    .line 1189
    .line 1190
    .line 1191
    move-result-object v3

    .line 1192
    new-instance v4, LG0/f;

    .line 1193
    .line 1194
    const/16 v6, 0x9

    .line 1195
    .line 1196
    invoke-direct {v4, v6, v8}, LG0/f;-><init>(ILjava/lang/Object;)V

    .line 1197
    .line 1198
    .line 1199
    invoke-virtual {v13, v3, v4}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 1200
    .line 1201
    .line 1202
    goto/16 :goto_4

    .line 1203
    .line 1204
    :cond_27
    instance-of v3, v2, Landroid/webkit/PermissionRequest;

    .line 1205
    .line 1206
    if-eqz v3, :cond_29

    .line 1207
    .line 1208
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1209
    .line 1210
    .line 1211
    move-object v3, v2

    .line 1212
    check-cast v3, Landroid/webkit/PermissionRequest;

    .line 1213
    .line 1214
    new-instance v6, LH0/h;

    .line 1215
    .line 1216
    const/16 v7, 0x15

    .line 1217
    .line 1218
    invoke-direct {v6, v7, v2}, LH0/h;-><init>(ILjava/lang/Object;)V

    .line 1219
    .line 1220
    .line 1221
    iget-object v7, v5, LH0/P;->b:LH0/e;

    .line 1222
    .line 1223
    invoke-virtual {v7, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 1224
    .line 1225
    .line 1226
    move-result v8

    .line 1227
    if-eqz v8, :cond_28

    .line 1228
    .line 1229
    goto/16 :goto_4

    .line 1230
    .line 1231
    :cond_28
    invoke-virtual {v7, v3}, LH0/e;->b(Ljava/lang/Object;)J

    .line 1232
    .line 1233
    .line 1234
    move-result-wide v7

    .line 1235
    invoke-virtual {v3}, Landroid/webkit/PermissionRequest;->getResources()[Ljava/lang/String;

    .line 1236
    .line 1237
    .line 1238
    move-result-object v3

    .line 1239
    invoke-static {v3}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 1240
    .line 1241
    .line 1242
    move-result-object v3

    .line 1243
    invoke-virtual {v5}, LH0/P;->a()LA0/n;

    .line 1244
    .line 1245
    .line 1246
    move-result-object v9

    .line 1247
    new-instance v10, LA0/e;

    .line 1248
    .line 1249
    iget-object v11, v5, LH0/P;->a:LA0/h;

    .line 1250
    .line 1251
    const-string v12, "dev.flutter.pigeon.webview_flutter_android.PermissionRequest.pigeon_newInstance"

    .line 1252
    .line 1253
    invoke-direct {v10, v11, v12, v9, v4}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 1254
    .line 1255
    .line 1256
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 1257
    .line 1258
    .line 1259
    move-result-object v4

    .line 1260
    filled-new-array {v4, v3}, [Ljava/lang/Object;

    .line 1261
    .line 1262
    .line 1263
    move-result-object v3

    .line 1264
    invoke-static {v3}, LK0/e;->R([Ljava/lang/Object;)Ljava/util/List;

    .line 1265
    .line 1266
    .line 1267
    move-result-object v3

    .line 1268
    new-instance v4, LG0/f;

    .line 1269
    .line 1270
    const/16 v7, 0xe

    .line 1271
    .line 1272
    invoke-direct {v4, v7, v6}, LG0/f;-><init>(ILjava/lang/Object;)V

    .line 1273
    .line 1274
    .line 1275
    invoke-virtual {v10, v3, v4}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 1276
    .line 1277
    .line 1278
    goto/16 :goto_4

    .line 1279
    .line 1280
    :cond_29
    instance-of v3, v2, Landroid/webkit/WebChromeClient$CustomViewCallback;

    .line 1281
    .line 1282
    if-eqz v3, :cond_2b

    .line 1283
    .line 1284
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1285
    .line 1286
    .line 1287
    move-object v3, v2

    .line 1288
    check-cast v3, Landroid/webkit/WebChromeClient$CustomViewCallback;

    .line 1289
    .line 1290
    new-instance v6, LH0/h;

    .line 1291
    .line 1292
    const/16 v7, 0x16

    .line 1293
    .line 1294
    invoke-direct {v6, v7, v2}, LH0/h;-><init>(ILjava/lang/Object;)V

    .line 1295
    .line 1296
    .line 1297
    iget-object v7, v5, LH0/P;->b:LH0/e;

    .line 1298
    .line 1299
    invoke-virtual {v7, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 1300
    .line 1301
    .line 1302
    move-result v8

    .line 1303
    if-eqz v8, :cond_2a

    .line 1304
    .line 1305
    goto/16 :goto_4

    .line 1306
    .line 1307
    :cond_2a
    invoke-virtual {v7, v3}, LH0/e;->b(Ljava/lang/Object;)J

    .line 1308
    .line 1309
    .line 1310
    move-result-wide v7

    .line 1311
    invoke-virtual {v5}, LH0/P;->a()LA0/n;

    .line 1312
    .line 1313
    .line 1314
    move-result-object v3

    .line 1315
    new-instance v9, LA0/e;

    .line 1316
    .line 1317
    iget-object v10, v5, LH0/P;->a:LA0/h;

    .line 1318
    .line 1319
    const-string v11, "dev.flutter.pigeon.webview_flutter_android.CustomViewCallback.pigeon_newInstance"

    .line 1320
    .line 1321
    invoke-direct {v9, v10, v11, v3, v4}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 1322
    .line 1323
    .line 1324
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 1325
    .line 1326
    .line 1327
    move-result-object v3

    .line 1328
    invoke-static {v3}, Li1/a;->u(Ljava/lang/Object;)Ljava/util/List;

    .line 1329
    .line 1330
    .line 1331
    move-result-object v3

    .line 1332
    new-instance v4, LG0/f;

    .line 1333
    .line 1334
    const/4 v7, 0x7

    .line 1335
    invoke-direct {v4, v7, v6}, LG0/f;-><init>(ILjava/lang/Object;)V

    .line 1336
    .line 1337
    .line 1338
    invoke-virtual {v9, v3, v4}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 1339
    .line 1340
    .line 1341
    goto/16 :goto_4

    .line 1342
    .line 1343
    :cond_2b
    instance-of v3, v2, Landroid/view/View;

    .line 1344
    .line 1345
    if-eqz v3, :cond_2d

    .line 1346
    .line 1347
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1348
    .line 1349
    .line 1350
    move-object v3, v2

    .line 1351
    check-cast v3, Landroid/view/View;

    .line 1352
    .line 1353
    new-instance v6, LH0/h;

    .line 1354
    .line 1355
    const/16 v7, 0x17

    .line 1356
    .line 1357
    invoke-direct {v6, v7, v2}, LH0/h;-><init>(ILjava/lang/Object;)V

    .line 1358
    .line 1359
    .line 1360
    iget-object v7, v5, LH0/P;->b:LH0/e;

    .line 1361
    .line 1362
    invoke-virtual {v7, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 1363
    .line 1364
    .line 1365
    move-result v8

    .line 1366
    if-eqz v8, :cond_2c

    .line 1367
    .line 1368
    goto/16 :goto_4

    .line 1369
    .line 1370
    :cond_2c
    invoke-virtual {v7, v3}, LH0/e;->b(Ljava/lang/Object;)J

    .line 1371
    .line 1372
    .line 1373
    move-result-wide v7

    .line 1374
    invoke-virtual {v5}, LH0/P;->a()LA0/n;

    .line 1375
    .line 1376
    .line 1377
    move-result-object v3

    .line 1378
    new-instance v9, LA0/e;

    .line 1379
    .line 1380
    iget-object v10, v5, LH0/P;->a:LA0/h;

    .line 1381
    .line 1382
    const-string v11, "dev.flutter.pigeon.webview_flutter_android.View.pigeon_newInstance"

    .line 1383
    .line 1384
    invoke-direct {v9, v10, v11, v3, v4}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 1385
    .line 1386
    .line 1387
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 1388
    .line 1389
    .line 1390
    move-result-object v3

    .line 1391
    invoke-static {v3}, Li1/a;->u(Ljava/lang/Object;)Ljava/util/List;

    .line 1392
    .line 1393
    .line 1394
    move-result-object v3

    .line 1395
    new-instance v4, LG0/f;

    .line 1396
    .line 1397
    const/16 v7, 0x15

    .line 1398
    .line 1399
    invoke-direct {v4, v7, v6}, LG0/f;-><init>(ILjava/lang/Object;)V

    .line 1400
    .line 1401
    .line 1402
    invoke-virtual {v9, v3, v4}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 1403
    .line 1404
    .line 1405
    goto/16 :goto_4

    .line 1406
    .line 1407
    :cond_2d
    instance-of v3, v2, Landroid/webkit/GeolocationPermissions$Callback;

    .line 1408
    .line 1409
    if-eqz v3, :cond_2f

    .line 1410
    .line 1411
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1412
    .line 1413
    .line 1414
    move-object v3, v2

    .line 1415
    check-cast v3, Landroid/webkit/GeolocationPermissions$Callback;

    .line 1416
    .line 1417
    new-instance v6, LH0/h;

    .line 1418
    .line 1419
    const/16 v7, 0x18

    .line 1420
    .line 1421
    invoke-direct {v6, v7, v2}, LH0/h;-><init>(ILjava/lang/Object;)V

    .line 1422
    .line 1423
    .line 1424
    iget-object v7, v5, LH0/P;->b:LH0/e;

    .line 1425
    .line 1426
    invoke-virtual {v7, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 1427
    .line 1428
    .line 1429
    move-result v8

    .line 1430
    if-eqz v8, :cond_2e

    .line 1431
    .line 1432
    goto/16 :goto_4

    .line 1433
    .line 1434
    :cond_2e
    invoke-virtual {v7, v3}, LH0/e;->b(Ljava/lang/Object;)J

    .line 1435
    .line 1436
    .line 1437
    move-result-wide v7

    .line 1438
    invoke-virtual {v5}, LH0/P;->a()LA0/n;

    .line 1439
    .line 1440
    .line 1441
    move-result-object v3

    .line 1442
    new-instance v9, LA0/e;

    .line 1443
    .line 1444
    iget-object v10, v5, LH0/P;->a:LA0/h;

    .line 1445
    .line 1446
    const-string v11, "dev.flutter.pigeon.webview_flutter_android.GeolocationPermissionsCallback.pigeon_newInstance"

    .line 1447
    .line 1448
    invoke-direct {v9, v10, v11, v3, v4}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 1449
    .line 1450
    .line 1451
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 1452
    .line 1453
    .line 1454
    move-result-object v3

    .line 1455
    invoke-static {v3}, Li1/a;->u(Ljava/lang/Object;)Ljava/util/List;

    .line 1456
    .line 1457
    .line 1458
    move-result-object v3

    .line 1459
    new-instance v4, LG0/f;

    .line 1460
    .line 1461
    const/16 v7, 0xb

    .line 1462
    .line 1463
    invoke-direct {v4, v7, v6}, LG0/f;-><init>(ILjava/lang/Object;)V

    .line 1464
    .line 1465
    .line 1466
    invoke-virtual {v9, v3, v4}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 1467
    .line 1468
    .line 1469
    goto/16 :goto_4

    .line 1470
    .line 1471
    :cond_2f
    instance-of v3, v2, Landroid/webkit/HttpAuthHandler;

    .line 1472
    .line 1473
    if-eqz v3, :cond_31

    .line 1474
    .line 1475
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1476
    .line 1477
    .line 1478
    move-object v3, v2

    .line 1479
    check-cast v3, Landroid/webkit/HttpAuthHandler;

    .line 1480
    .line 1481
    new-instance v6, LH0/h;

    .line 1482
    .line 1483
    const/4 v7, 0x1

    .line 1484
    invoke-direct {v6, v7, v2}, LH0/h;-><init>(ILjava/lang/Object;)V

    .line 1485
    .line 1486
    .line 1487
    iget-object v7, v5, LH0/P;->b:LH0/e;

    .line 1488
    .line 1489
    invoke-virtual {v7, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 1490
    .line 1491
    .line 1492
    move-result v8

    .line 1493
    if-eqz v8, :cond_30

    .line 1494
    .line 1495
    goto/16 :goto_4

    .line 1496
    .line 1497
    :cond_30
    invoke-virtual {v7, v3}, LH0/e;->b(Ljava/lang/Object;)J

    .line 1498
    .line 1499
    .line 1500
    move-result-wide v7

    .line 1501
    invoke-virtual {v5}, LH0/P;->a()LA0/n;

    .line 1502
    .line 1503
    .line 1504
    move-result-object v3

    .line 1505
    new-instance v9, LA0/e;

    .line 1506
    .line 1507
    iget-object v10, v5, LH0/P;->a:LA0/h;

    .line 1508
    .line 1509
    const-string v11, "dev.flutter.pigeon.webview_flutter_android.HttpAuthHandler.pigeon_newInstance"

    .line 1510
    .line 1511
    invoke-direct {v9, v10, v11, v3, v4}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 1512
    .line 1513
    .line 1514
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 1515
    .line 1516
    .line 1517
    move-result-object v3

    .line 1518
    invoke-static {v3}, Li1/a;->u(Ljava/lang/Object;)Ljava/util/List;

    .line 1519
    .line 1520
    .line 1521
    move-result-object v3

    .line 1522
    new-instance v4, LG0/f;

    .line 1523
    .line 1524
    const/16 v7, 0xc

    .line 1525
    .line 1526
    invoke-direct {v4, v7, v6}, LG0/f;-><init>(ILjava/lang/Object;)V

    .line 1527
    .line 1528
    .line 1529
    invoke-virtual {v9, v3, v4}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 1530
    .line 1531
    .line 1532
    goto/16 :goto_4

    .line 1533
    .line 1534
    :cond_31
    instance-of v3, v2, Landroid/os/Message;

    .line 1535
    .line 1536
    if-eqz v3, :cond_33

    .line 1537
    .line 1538
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1539
    .line 1540
    .line 1541
    move-object v3, v2

    .line 1542
    check-cast v3, Landroid/os/Message;

    .line 1543
    .line 1544
    new-instance v6, LH0/h;

    .line 1545
    .line 1546
    const/4 v7, 0x2

    .line 1547
    invoke-direct {v6, v7, v2}, LH0/h;-><init>(ILjava/lang/Object;)V

    .line 1548
    .line 1549
    .line 1550
    iget-object v7, v5, LH0/P;->b:LH0/e;

    .line 1551
    .line 1552
    invoke-virtual {v7, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 1553
    .line 1554
    .line 1555
    move-result v8

    .line 1556
    if-eqz v8, :cond_32

    .line 1557
    .line 1558
    goto/16 :goto_4

    .line 1559
    .line 1560
    :cond_32
    invoke-virtual {v7, v3}, LH0/e;->b(Ljava/lang/Object;)J

    .line 1561
    .line 1562
    .line 1563
    move-result-wide v7

    .line 1564
    invoke-virtual {v5}, LH0/P;->a()LA0/n;

    .line 1565
    .line 1566
    .line 1567
    move-result-object v3

    .line 1568
    new-instance v9, LA0/e;

    .line 1569
    .line 1570
    iget-object v10, v5, LH0/P;->a:LA0/h;

    .line 1571
    .line 1572
    const-string v11, "dev.flutter.pigeon.webview_flutter_android.AndroidMessage.pigeon_newInstance"

    .line 1573
    .line 1574
    invoke-direct {v9, v10, v11, v3, v4}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 1575
    .line 1576
    .line 1577
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 1578
    .line 1579
    .line 1580
    move-result-object v3

    .line 1581
    invoke-static {v3}, Li1/a;->u(Ljava/lang/Object;)Ljava/util/List;

    .line 1582
    .line 1583
    .line 1584
    move-result-object v3

    .line 1585
    new-instance v4, LG0/f;

    .line 1586
    .line 1587
    const/4 v7, 0x2

    .line 1588
    invoke-direct {v4, v7, v6}, LG0/f;-><init>(ILjava/lang/Object;)V

    .line 1589
    .line 1590
    .line 1591
    invoke-virtual {v9, v3, v4}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 1592
    .line 1593
    .line 1594
    goto/16 :goto_4

    .line 1595
    .line 1596
    :cond_33
    instance-of v3, v2, Landroid/webkit/ClientCertRequest;

    .line 1597
    .line 1598
    if-eqz v3, :cond_35

    .line 1599
    .line 1600
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1601
    .line 1602
    .line 1603
    move-object v3, v2

    .line 1604
    check-cast v3, Landroid/webkit/ClientCertRequest;

    .line 1605
    .line 1606
    new-instance v6, LH0/h;

    .line 1607
    .line 1608
    const/4 v7, 0x3

    .line 1609
    invoke-direct {v6, v7, v2}, LH0/h;-><init>(ILjava/lang/Object;)V

    .line 1610
    .line 1611
    .line 1612
    iget-object v7, v5, LH0/P;->b:LH0/e;

    .line 1613
    .line 1614
    invoke-virtual {v7, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 1615
    .line 1616
    .line 1617
    move-result v8

    .line 1618
    if-eqz v8, :cond_34

    .line 1619
    .line 1620
    goto/16 :goto_4

    .line 1621
    .line 1622
    :cond_34
    invoke-virtual {v7, v3}, LH0/e;->b(Ljava/lang/Object;)J

    .line 1623
    .line 1624
    .line 1625
    move-result-wide v7

    .line 1626
    invoke-virtual {v5}, LH0/P;->a()LA0/n;

    .line 1627
    .line 1628
    .line 1629
    move-result-object v3

    .line 1630
    new-instance v9, LA0/e;

    .line 1631
    .line 1632
    iget-object v10, v5, LH0/P;->a:LA0/h;

    .line 1633
    .line 1634
    const-string v11, "dev.flutter.pigeon.webview_flutter_android.ClientCertRequest.pigeon_newInstance"

    .line 1635
    .line 1636
    invoke-direct {v9, v10, v11, v3, v4}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 1637
    .line 1638
    .line 1639
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 1640
    .line 1641
    .line 1642
    move-result-object v3

    .line 1643
    invoke-static {v3}, Li1/a;->u(Ljava/lang/Object;)Ljava/util/List;

    .line 1644
    .line 1645
    .line 1646
    move-result-object v3

    .line 1647
    new-instance v4, LG0/f;

    .line 1648
    .line 1649
    const/4 v7, 0x4

    .line 1650
    invoke-direct {v4, v7, v6}, LG0/f;-><init>(ILjava/lang/Object;)V

    .line 1651
    .line 1652
    .line 1653
    invoke-virtual {v9, v3, v4}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 1654
    .line 1655
    .line 1656
    goto/16 :goto_4

    .line 1657
    .line 1658
    :cond_35
    instance-of v3, v2, Ljava/security/PrivateKey;

    .line 1659
    .line 1660
    if-eqz v3, :cond_37

    .line 1661
    .line 1662
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1663
    .line 1664
    .line 1665
    move-object v3, v2

    .line 1666
    check-cast v3, Ljava/security/PrivateKey;

    .line 1667
    .line 1668
    new-instance v6, LH0/h;

    .line 1669
    .line 1670
    const/4 v7, 0x4

    .line 1671
    invoke-direct {v6, v7, v2}, LH0/h;-><init>(ILjava/lang/Object;)V

    .line 1672
    .line 1673
    .line 1674
    iget-object v7, v5, LH0/P;->b:LH0/e;

    .line 1675
    .line 1676
    invoke-virtual {v7, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 1677
    .line 1678
    .line 1679
    move-result v8

    .line 1680
    if-eqz v8, :cond_36

    .line 1681
    .line 1682
    goto/16 :goto_4

    .line 1683
    .line 1684
    :cond_36
    invoke-virtual {v7, v3}, LH0/e;->b(Ljava/lang/Object;)J

    .line 1685
    .line 1686
    .line 1687
    move-result-wide v7

    .line 1688
    invoke-virtual {v5}, LH0/P;->a()LA0/n;

    .line 1689
    .line 1690
    .line 1691
    move-result-object v3

    .line 1692
    new-instance v9, LA0/e;

    .line 1693
    .line 1694
    iget-object v10, v5, LH0/P;->a:LA0/h;

    .line 1695
    .line 1696
    const-string v11, "dev.flutter.pigeon.webview_flutter_android.PrivateKey.pigeon_newInstance"

    .line 1697
    .line 1698
    invoke-direct {v9, v10, v11, v3, v4}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 1699
    .line 1700
    .line 1701
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 1702
    .line 1703
    .line 1704
    move-result-object v3

    .line 1705
    invoke-static {v3}, Li1/a;->u(Ljava/lang/Object;)Ljava/util/List;

    .line 1706
    .line 1707
    .line 1708
    move-result-object v3

    .line 1709
    new-instance v4, LG0/f;

    .line 1710
    .line 1711
    const/16 v7, 0xf

    .line 1712
    .line 1713
    invoke-direct {v4, v7, v6}, LG0/f;-><init>(ILjava/lang/Object;)V

    .line 1714
    .line 1715
    .line 1716
    invoke-virtual {v9, v3, v4}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 1717
    .line 1718
    .line 1719
    goto/16 :goto_4

    .line 1720
    .line 1721
    :cond_37
    instance-of v3, v2, Ljava/security/cert/X509Certificate;

    .line 1722
    .line 1723
    if-eqz v3, :cond_39

    .line 1724
    .line 1725
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1726
    .line 1727
    .line 1728
    move-object v3, v2

    .line 1729
    check-cast v3, Ljava/security/cert/X509Certificate;

    .line 1730
    .line 1731
    new-instance v6, LH0/h;

    .line 1732
    .line 1733
    const/4 v7, 0x5

    .line 1734
    invoke-direct {v6, v7, v2}, LH0/h;-><init>(ILjava/lang/Object;)V

    .line 1735
    .line 1736
    .line 1737
    iget-object v7, v5, LH0/P;->b:LH0/e;

    .line 1738
    .line 1739
    invoke-virtual {v7, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 1740
    .line 1741
    .line 1742
    move-result v8

    .line 1743
    if-eqz v8, :cond_38

    .line 1744
    .line 1745
    goto/16 :goto_4

    .line 1746
    .line 1747
    :cond_38
    invoke-virtual {v7, v3}, LH0/e;->b(Ljava/lang/Object;)J

    .line 1748
    .line 1749
    .line 1750
    move-result-wide v7

    .line 1751
    invoke-virtual {v5}, LH0/P;->a()LA0/n;

    .line 1752
    .line 1753
    .line 1754
    move-result-object v3

    .line 1755
    new-instance v9, LA0/e;

    .line 1756
    .line 1757
    iget-object v10, v5, LH0/P;->a:LA0/h;

    .line 1758
    .line 1759
    const-string v11, "dev.flutter.pigeon.webview_flutter_android.X509Certificate.pigeon_newInstance"

    .line 1760
    .line 1761
    invoke-direct {v9, v10, v11, v3, v4}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 1762
    .line 1763
    .line 1764
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 1765
    .line 1766
    .line 1767
    move-result-object v3

    .line 1768
    invoke-static {v3}, Li1/a;->u(Ljava/lang/Object;)Ljava/util/List;

    .line 1769
    .line 1770
    .line 1771
    move-result-object v3

    .line 1772
    new-instance v4, LH0/O;

    .line 1773
    .line 1774
    const/4 v7, 0x2

    .line 1775
    invoke-direct {v4, v7, v6}, LH0/O;-><init>(ILjava/lang/Object;)V

    .line 1776
    .line 1777
    .line 1778
    invoke-virtual {v9, v3, v4}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 1779
    .line 1780
    .line 1781
    goto/16 :goto_4

    .line 1782
    .line 1783
    :cond_39
    instance-of v3, v2, Landroid/webkit/SslErrorHandler;

    .line 1784
    .line 1785
    if-eqz v3, :cond_3b

    .line 1786
    .line 1787
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1788
    .line 1789
    .line 1790
    move-object v3, v2

    .line 1791
    check-cast v3, Landroid/webkit/SslErrorHandler;

    .line 1792
    .line 1793
    new-instance v6, LH0/h;

    .line 1794
    .line 1795
    const/4 v7, 0x6

    .line 1796
    invoke-direct {v6, v7, v2}, LH0/h;-><init>(ILjava/lang/Object;)V

    .line 1797
    .line 1798
    .line 1799
    iget-object v7, v5, LH0/P;->b:LH0/e;

    .line 1800
    .line 1801
    invoke-virtual {v7, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 1802
    .line 1803
    .line 1804
    move-result v8

    .line 1805
    if-eqz v8, :cond_3a

    .line 1806
    .line 1807
    goto/16 :goto_4

    .line 1808
    .line 1809
    :cond_3a
    invoke-virtual {v7, v3}, LH0/e;->b(Ljava/lang/Object;)J

    .line 1810
    .line 1811
    .line 1812
    move-result-wide v7

    .line 1813
    invoke-virtual {v5}, LH0/P;->a()LA0/n;

    .line 1814
    .line 1815
    .line 1816
    move-result-object v3

    .line 1817
    new-instance v9, LA0/e;

    .line 1818
    .line 1819
    iget-object v10, v5, LH0/P;->a:LA0/h;

    .line 1820
    .line 1821
    const-string v11, "dev.flutter.pigeon.webview_flutter_android.SslErrorHandler.pigeon_newInstance"

    .line 1822
    .line 1823
    invoke-direct {v9, v10, v11, v3, v4}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 1824
    .line 1825
    .line 1826
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 1827
    .line 1828
    .line 1829
    move-result-object v3

    .line 1830
    invoke-static {v3}, Li1/a;->u(Ljava/lang/Object;)Ljava/util/List;

    .line 1831
    .line 1832
    .line 1833
    move-result-object v3

    .line 1834
    new-instance v4, LG0/f;

    .line 1835
    .line 1836
    const/16 v7, 0x14

    .line 1837
    .line 1838
    invoke-direct {v4, v7, v6}, LG0/f;-><init>(ILjava/lang/Object;)V

    .line 1839
    .line 1840
    .line 1841
    invoke-virtual {v9, v3, v4}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 1842
    .line 1843
    .line 1844
    goto/16 :goto_4

    .line 1845
    .line 1846
    :cond_3b
    instance-of v3, v2, Landroid/net/http/SslError;

    .line 1847
    .line 1848
    if-eqz v3, :cond_3d

    .line 1849
    .line 1850
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1851
    .line 1852
    .line 1853
    move-object v3, v2

    .line 1854
    check-cast v3, Landroid/net/http/SslError;

    .line 1855
    .line 1856
    new-instance v6, LH0/h;

    .line 1857
    .line 1858
    const/4 v7, 0x7

    .line 1859
    invoke-direct {v6, v7, v2}, LH0/h;-><init>(ILjava/lang/Object;)V

    .line 1860
    .line 1861
    .line 1862
    iget-object v7, v5, LH0/P;->b:LH0/e;

    .line 1863
    .line 1864
    invoke-virtual {v7, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 1865
    .line 1866
    .line 1867
    move-result v8

    .line 1868
    if-eqz v8, :cond_3c

    .line 1869
    .line 1870
    goto/16 :goto_4

    .line 1871
    .line 1872
    :cond_3c
    invoke-virtual {v7, v3}, LH0/e;->b(Ljava/lang/Object;)J

    .line 1873
    .line 1874
    .line 1875
    move-result-wide v7

    .line 1876
    invoke-virtual {v3}, Landroid/net/http/SslError;->getCertificate()Landroid/net/http/SslCertificate;

    .line 1877
    .line 1878
    .line 1879
    move-result-object v9

    .line 1880
    invoke-virtual {v3}, Landroid/net/http/SslError;->getUrl()Ljava/lang/String;

    .line 1881
    .line 1882
    .line 1883
    move-result-object v3

    .line 1884
    invoke-virtual {v5}, LH0/P;->a()LA0/n;

    .line 1885
    .line 1886
    .line 1887
    move-result-object v10

    .line 1888
    new-instance v11, LA0/e;

    .line 1889
    .line 1890
    iget-object v12, v5, LH0/P;->a:LA0/h;

    .line 1891
    .line 1892
    const-string v13, "dev.flutter.pigeon.webview_flutter_android.SslError.pigeon_newInstance"

    .line 1893
    .line 1894
    invoke-direct {v11, v12, v13, v10, v4}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 1895
    .line 1896
    .line 1897
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 1898
    .line 1899
    .line 1900
    move-result-object v4

    .line 1901
    filled-new-array {v4, v9, v3}, [Ljava/lang/Object;

    .line 1902
    .line 1903
    .line 1904
    move-result-object v3

    .line 1905
    invoke-static {v3}, LK0/e;->R([Ljava/lang/Object;)Ljava/util/List;

    .line 1906
    .line 1907
    .line 1908
    move-result-object v3

    .line 1909
    new-instance v4, LG0/f;

    .line 1910
    .line 1911
    const/16 v7, 0x12

    .line 1912
    .line 1913
    invoke-direct {v4, v7, v6}, LG0/f;-><init>(ILjava/lang/Object;)V

    .line 1914
    .line 1915
    .line 1916
    invoke-virtual {v11, v3, v4}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 1917
    .line 1918
    .line 1919
    goto/16 :goto_4

    .line 1920
    .line 1921
    :cond_3d
    instance-of v3, v2, Landroid/net/http/SslCertificate$DName;

    .line 1922
    .line 1923
    if-eqz v3, :cond_3f

    .line 1924
    .line 1925
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1926
    .line 1927
    .line 1928
    move-object v3, v2

    .line 1929
    check-cast v3, Landroid/net/http/SslCertificate$DName;

    .line 1930
    .line 1931
    new-instance v6, LH0/h;

    .line 1932
    .line 1933
    const/16 v7, 0x8

    .line 1934
    .line 1935
    invoke-direct {v6, v7, v2}, LH0/h;-><init>(ILjava/lang/Object;)V

    .line 1936
    .line 1937
    .line 1938
    iget-object v7, v5, LH0/P;->b:LH0/e;

    .line 1939
    .line 1940
    invoke-virtual {v7, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 1941
    .line 1942
    .line 1943
    move-result v8

    .line 1944
    if-eqz v8, :cond_3e

    .line 1945
    .line 1946
    goto/16 :goto_4

    .line 1947
    .line 1948
    :cond_3e
    invoke-virtual {v7, v3}, LH0/e;->b(Ljava/lang/Object;)J

    .line 1949
    .line 1950
    .line 1951
    move-result-wide v7

    .line 1952
    invoke-virtual {v5}, LH0/P;->a()LA0/n;

    .line 1953
    .line 1954
    .line 1955
    move-result-object v3

    .line 1956
    new-instance v9, LA0/e;

    .line 1957
    .line 1958
    iget-object v10, v5, LH0/P;->a:LA0/h;

    .line 1959
    .line 1960
    const-string v11, "dev.flutter.pigeon.webview_flutter_android.SslCertificateDName.pigeon_newInstance"

    .line 1961
    .line 1962
    invoke-direct {v9, v10, v11, v3, v4}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 1963
    .line 1964
    .line 1965
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 1966
    .line 1967
    .line 1968
    move-result-object v3

    .line 1969
    invoke-static {v3}, Li1/a;->u(Ljava/lang/Object;)Ljava/util/List;

    .line 1970
    .line 1971
    .line 1972
    move-result-object v3

    .line 1973
    new-instance v4, LG0/f;

    .line 1974
    .line 1975
    const/16 v7, 0x11

    .line 1976
    .line 1977
    invoke-direct {v4, v7, v6}, LG0/f;-><init>(ILjava/lang/Object;)V

    .line 1978
    .line 1979
    .line 1980
    invoke-virtual {v9, v3, v4}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 1981
    .line 1982
    .line 1983
    goto/16 :goto_4

    .line 1984
    .line 1985
    :cond_3f
    instance-of v3, v2, Landroid/net/http/SslCertificate;

    .line 1986
    .line 1987
    if-eqz v3, :cond_41

    .line 1988
    .line 1989
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1990
    .line 1991
    .line 1992
    move-object v3, v2

    .line 1993
    check-cast v3, Landroid/net/http/SslCertificate;

    .line 1994
    .line 1995
    new-instance v6, LH0/h;

    .line 1996
    .line 1997
    const/16 v7, 0x9

    .line 1998
    .line 1999
    invoke-direct {v6, v7, v2}, LH0/h;-><init>(ILjava/lang/Object;)V

    .line 2000
    .line 2001
    .line 2002
    iget-object v7, v5, LH0/P;->b:LH0/e;

    .line 2003
    .line 2004
    invoke-virtual {v7, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 2005
    .line 2006
    .line 2007
    move-result v8

    .line 2008
    if-eqz v8, :cond_40

    .line 2009
    .line 2010
    goto :goto_4

    .line 2011
    :cond_40
    invoke-virtual {v7, v3}, LH0/e;->b(Ljava/lang/Object;)J

    .line 2012
    .line 2013
    .line 2014
    move-result-wide v7

    .line 2015
    invoke-virtual {v5}, LH0/P;->a()LA0/n;

    .line 2016
    .line 2017
    .line 2018
    move-result-object v3

    .line 2019
    new-instance v9, LA0/e;

    .line 2020
    .line 2021
    iget-object v10, v5, LH0/P;->a:LA0/h;

    .line 2022
    .line 2023
    const-string v11, "dev.flutter.pigeon.webview_flutter_android.SslCertificate.pigeon_newInstance"

    .line 2024
    .line 2025
    invoke-direct {v9, v10, v11, v3, v4}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 2026
    .line 2027
    .line 2028
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 2029
    .line 2030
    .line 2031
    move-result-object v3

    .line 2032
    invoke-static {v3}, Li1/a;->u(Ljava/lang/Object;)Ljava/util/List;

    .line 2033
    .line 2034
    .line 2035
    move-result-object v3

    .line 2036
    new-instance v4, LG0/f;

    .line 2037
    .line 2038
    const/16 v7, 0x10

    .line 2039
    .line 2040
    invoke-direct {v4, v7, v6}, LG0/f;-><init>(ILjava/lang/Object;)V

    .line 2041
    .line 2042
    .line 2043
    invoke-virtual {v9, v3, v4}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 2044
    .line 2045
    .line 2046
    goto :goto_4

    .line 2047
    :cond_41
    instance-of v3, v2, Ljava/security/cert/Certificate;

    .line 2048
    .line 2049
    if-eqz v3, :cond_43

    .line 2050
    .line 2051
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2052
    .line 2053
    .line 2054
    move-object v3, v2

    .line 2055
    check-cast v3, Ljava/security/cert/Certificate;

    .line 2056
    .line 2057
    new-instance v6, LH0/h;

    .line 2058
    .line 2059
    const/16 v7, 0xa

    .line 2060
    .line 2061
    invoke-direct {v6, v7, v2}, LH0/h;-><init>(ILjava/lang/Object;)V

    .line 2062
    .line 2063
    .line 2064
    iget-object v7, v5, LH0/P;->b:LH0/e;

    .line 2065
    .line 2066
    invoke-virtual {v7, v3}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 2067
    .line 2068
    .line 2069
    move-result v8

    .line 2070
    if-eqz v8, :cond_42

    .line 2071
    .line 2072
    goto :goto_4

    .line 2073
    :cond_42
    invoke-virtual {v7, v3}, LH0/e;->b(Ljava/lang/Object;)J

    .line 2074
    .line 2075
    .line 2076
    move-result-wide v7

    .line 2077
    invoke-virtual {v5}, LH0/P;->a()LA0/n;

    .line 2078
    .line 2079
    .line 2080
    move-result-object v3

    .line 2081
    new-instance v9, LA0/e;

    .line 2082
    .line 2083
    iget-object v10, v5, LH0/P;->a:LA0/h;

    .line 2084
    .line 2085
    const-string v11, "dev.flutter.pigeon.webview_flutter_android.Certificate.pigeon_newInstance"

    .line 2086
    .line 2087
    invoke-direct {v9, v10, v11, v3, v4}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 2088
    .line 2089
    .line 2090
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 2091
    .line 2092
    .line 2093
    move-result-object v3

    .line 2094
    invoke-static {v3}, Li1/a;->u(Ljava/lang/Object;)Ljava/util/List;

    .line 2095
    .line 2096
    .line 2097
    move-result-object v3

    .line 2098
    new-instance v4, LG0/f;

    .line 2099
    .line 2100
    const/4 v7, 0x3

    .line 2101
    invoke-direct {v4, v7, v6}, LG0/f;-><init>(ILjava/lang/Object;)V

    .line 2102
    .line 2103
    .line 2104
    invoke-virtual {v9, v3, v4}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 2105
    .line 2106
    .line 2107
    :cond_43
    :goto_4
    iget-object v3, v5, LH0/P;->b:LH0/e;

    .line 2108
    .line 2109
    invoke-virtual {v3, v2}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 2110
    .line 2111
    .line 2112
    move-result v3

    .line 2113
    if-eqz v3, :cond_45

    .line 2114
    .line 2115
    const/16 v3, 0x80

    .line 2116
    .line 2117
    invoke-virtual {v1, v3}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 2118
    .line 2119
    .line 2120
    iget-object v3, v5, LH0/P;->b:LH0/e;

    .line 2121
    .line 2122
    invoke-virtual {v3}, LH0/e;->f()V

    .line 2123
    .line 2124
    .line 2125
    iget-object v4, v3, LH0/e;->b:Ljava/util/WeakHashMap;

    .line 2126
    .line 2127
    new-instance v5, LH0/d;

    .line 2128
    .line 2129
    invoke-direct {v5, v2}, LH0/d;-><init>(Ljava/lang/Object;)V

    .line 2130
    .line 2131
    .line 2132
    invoke-virtual {v4, v5}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 2133
    .line 2134
    .line 2135
    move-result-object v4

    .line 2136
    check-cast v4, Ljava/lang/Long;

    .line 2137
    .line 2138
    if-eqz v4, :cond_44

    .line 2139
    .line 2140
    iget-object v3, v3, LH0/e;->d:Ljava/util/HashMap;

    .line 2141
    .line 2142
    invoke-virtual {v3, v4, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 2143
    .line 2144
    .line 2145
    :cond_44
    invoke-virtual {v0, v1, v4}, LH0/i;->k(LA0/s;Ljava/lang/Object;)V

    .line 2146
    .line 2147
    .line 2148
    return-void

    .line 2149
    :cond_45
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 2150
    .line 2151
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2152
    .line 2153
    .line 2154
    move-result-object v3

    .line 2155
    invoke-virtual {v3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 2156
    .line 2157
    .line 2158
    move-result-object v3

    .line 2159
    new-instance v4, Ljava/lang/StringBuilder;

    .line 2160
    .line 2161
    const-string v5, "Unsupported value: \'"

    .line 2162
    .line 2163
    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 2164
    .line 2165
    .line 2166
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 2167
    .line 2168
    .line 2169
    const-string v2, "\' of type \'"

    .line 2170
    .line 2171
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2172
    .line 2173
    .line 2174
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2175
    .line 2176
    .line 2177
    const-string v2, "\'"

    .line 2178
    .line 2179
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2180
    .line 2181
    .line 2182
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 2183
    .line 2184
    .line 2185
    move-result-object v2

    .line 2186
    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 2187
    .line 2188
    .line 2189
    throw v1

    .line 2190
    :cond_46
    :goto_5
    invoke-super/range {p0 .. p2}, LH0/b;->k(LA0/s;Ljava/lang/Object;)V

    .line 2191
    .line 2192
    .line 2193
    return-void
    .line 2194
    .line 2195
    .line 2196
    .line 2197
    .line 2198
    .line 2199
    .line 2200
    .line 2201
    .line 2202
    .line 2203
    .line 2204
    .line 2205
    .line 2206
    .line 2207
    .line 2208
    .line 2209
    .line 2210
    .line 2211
    .line 2212
    .line 2213
    .line 2214
    .line 2215
    .line 2216
    .line 2217
    .line 2218
    .line 2219
    .line 2220
    .line 2221
    .line 2222
    .line 2223
    .line 2224
    .line 2225
    .line 2226
    .line 2227
    .line 2228
    .line 2229
    .line 2230
    .line 2231
    .line 2232
    .line 2233
    .line 2234
    .line 2235
    .line 2236
    .line 2237
    .line 2238
    .line 2239
    .line 2240
    .line 2241
    .line 2242
    .line 2243
    .line 2244
    .line 2245
    .line 2246
    .line 2247
    .line 2248
    .line 2249
    .line 2250
    .line 2251
    .line 2252
    .line 2253
    .line 2254
    .line 2255
    .line 2256
    .line 2257
    .line 2258
    .line 2259
    .line 2260
    .line 2261
    .line 2262
    .line 2263
    .line 2264
    .line 2265
    .line 2266
    .line 2267
    .line 2268
    .line 2269
    .line 2270
    .line 2271
    .line 2272
    .line 2273
    .line 2274
    .line 2275
    .line 2276
    .line 2277
    .line 2278
    .line 2279
    .line 2280
    .line 2281
    .line 2282
    .line 2283
    .line 2284
    .line 2285
    .line 2286
    .line 2287
    .line 2288
    .line 2289
    .line 2290
    .line 2291
    .line 2292
    .line 2293
    .line 2294
    .line 2295
    .line 2296
    .line 2297
    .line 2298
    .line 2299
    .line 2300
    .line 2301
    .line 2302
    .line 2303
    .line 2304
    .line 2305
    .line 2306
    .line 2307
    .line 2308
    .line 2309
    .line 2310
    .line 2311
    .line 2312
    .line 2313
    .line 2314
    .line 2315
    .line 2316
    .line 2317
    .line 2318
    .line 2319
    .line 2320
    .line 2321
    .line 2322
    .line 2323
    .line 2324
    .line 2325
    .line 2326
    .line 2327
    .line 2328
    .line 2329
    .line 2330
    .line 2331
    .line 2332
    .line 2333
    .line 2334
    .line 2335
    .line 2336
    .line 2337
    .line 2338
    .line 2339
    .line 2340
    .line 2341
    .line 2342
    .line 2343
    .line 2344
    .line 2345
    .line 2346
    .line 2347
    .line 2348
    .line 2349
    .line 2350
    .line 2351
    .line 2352
    .line 2353
    .line 2354
    .line 2355
    .line 2356
    .line 2357
    .line 2358
    .line 2359
    .line 2360
    .line 2361
    .line 2362
    .line 2363
    .line 2364
    .line 2365
    .line 2366
    .line 2367
    .line 2368
    .line 2369
    .line 2370
    .line 2371
    .line 2372
    .line 2373
    .line 2374
    .line 2375
    .line 2376
    .line 2377
    .line 2378
    .line 2379
    .line 2380
    .line 2381
    .line 2382
    .line 2383
    .line 2384
    .line 2385
    .line 2386
    .line 2387
    .line 2388
    .line 2389
    .line 2390
    .line 2391
    .line 2392
    .line 2393
    .line 2394
    .line 2395
    .line 2396
    .line 2397
    .line 2398
    .line 2399
    .line 2400
    .line 2401
    .line 2402
    .line 2403
    .line 2404
    .line 2405
    .line 2406
    .line 2407
    .line 2408
    .line 2409
    .line 2410
    .line 2411
    .line 2412
    .line 2413
    .line 2414
    .line 2415
    .line 2416
    .line 2417
    .line 2418
    .line 2419
    .line 2420
    .line 2421
    .line 2422
    .line 2423
    .line 2424
    .line 2425
    .line 2426
    .line 2427
    .line 2428
    .line 2429
    .line 2430
    .line 2431
    .line 2432
    .line 2433
    .line 2434
.end method
