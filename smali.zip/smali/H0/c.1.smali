.class public final synthetic LH0/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LH0/c;->d:I

    iput-object p2, p0, LH0/c;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 9

    .line 1
    const/4 v0, 0x1

    .line 2
    const/4 v1, 0x0

    .line 3
    const/4 v2, 0x0

    .line 4
    iget v3, p0, LH0/c;->d:I

    .line 5
    .line 6
    packed-switch v3, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    iget-object v0, p0, LH0/c;->e:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v0, Lu0/c;

    .line 12
    .line 13
    iget-object v0, v0, Lu0/c;->b:Lu0/e;

    .line 14
    .line 15
    iget-object v0, v0, Lu0/e;->e:Lio/flutter/embedding/engine/FlutterJNI;

    .line 16
    .line 17
    invoke-virtual {v0}, Lio/flutter/embedding/engine/FlutterJNI;->prefetchDefaultFontManager()V

    .line 18
    .line 19
    .line 20
    return-void

    .line 21
    :pswitch_0
    iget-object v0, p0, LH0/c;->e:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v0, Lh/v;

    .line 24
    .line 25
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 26
    .line 27
    .line 28
    return-void

    .line 29
    :pswitch_1
    sget v0, Ldev/amirzr/flutter_v2ray_client/v2ray/services/V2rayVPNService;->g:I

    .line 30
    .line 31
    iget-object v0, p0, LH0/c;->e:Ljava/lang/Object;

    .line 32
    .line 33
    check-cast v0, Ldev/amirzr/flutter_v2ray_client/v2ray/services/V2rayVPNService;

    .line 34
    .line 35
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 36
    .line 37
    .line 38
    :try_start_0
    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    new-instance v2, Landroid/content/Intent;

    .line 43
    .line 44
    new-instance v3, Ljava/lang/StringBuilder;

    .line 45
    .line 46
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 47
    .line 48
    .line 49
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 50
    .line 51
    .line 52
    const-string v4, ".CONNECTED_V2RAY_SERVER_DELAY"

    .line 53
    .line 54
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 55
    .line 56
    .line 57
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object v3

    .line 61
    invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    invoke-virtual {v2, v1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 65
    .line 66
    .line 67
    const-string v1, "DELAY"

    .line 68
    .line 69
    invoke-static {}, Ll0/c;->b()Ll0/c;

    .line 70
    .line 71
    .line 72
    move-result-object v3

    .line 73
    invoke-virtual {v3}, Ll0/c;->a()Ljava/lang/Long;

    .line 74
    .line 75
    .line 76
    move-result-object v3

    .line 77
    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 78
    .line 79
    .line 80
    move-result-object v3

    .line 81
    invoke-virtual {v2, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 82
    .line 83
    .line 84
    invoke-virtual {v0, v2}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 85
    .line 86
    .line 87
    goto :goto_0

    .line 88
    :catch_0
    move-exception v0

    .line 89
    const-string v1, "V2rayVPNService"

    .line 90
    .line 91
    const-string v2, "Failed to send delay broadcast"

    .line 92
    .line 93
    invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 94
    .line 95
    .line 96
    :goto_0
    return-void

    .line 97
    :pswitch_2
    sget v0, Ldev/amirzr/flutter_v2ray_client/v2ray/services/V2rayProxyOnlyService;->d:I

    .line 98
    .line 99
    iget-object v0, p0, LH0/c;->e:Ljava/lang/Object;

    .line 100
    .line 101
    check-cast v0, Ldev/amirzr/flutter_v2ray_client/v2ray/services/V2rayProxyOnlyService;

    .line 102
    .line 103
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 104
    .line 105
    .line 106
    :try_start_1
    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    move-result-object v1

    .line 110
    new-instance v2, Landroid/content/Intent;

    .line 111
    .line 112
    new-instance v3, Ljava/lang/StringBuilder;

    .line 113
    .line 114
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 115
    .line 116
    .line 117
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 118
    .line 119
    .line 120
    const-string v4, ".CONNECTED_V2RAY_SERVER_DELAY"

    .line 121
    .line 122
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 123
    .line 124
    .line 125
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 126
    .line 127
    .line 128
    move-result-object v3

    .line 129
    invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 130
    .line 131
    .line 132
    invoke-virtual {v2, v1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 133
    .line 134
    .line 135
    const-string v1, "DELAY"

    .line 136
    .line 137
    invoke-static {}, Ll0/c;->b()Ll0/c;

    .line 138
    .line 139
    .line 140
    move-result-object v3

    .line 141
    invoke-virtual {v3}, Ll0/c;->a()Ljava/lang/Long;

    .line 142
    .line 143
    .line 144
    move-result-object v3

    .line 145
    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 146
    .line 147
    .line 148
    move-result-object v3

    .line 149
    invoke-virtual {v2, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 150
    .line 151
    .line 152
    invoke-virtual {v0, v2}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 153
    .line 154
    .line 155
    goto :goto_1

    .line 156
    :catch_1
    move-exception v0

    .line 157
    const-string v1, "V2rayProxyOnlyService"

    .line 158
    .line 159
    const-string v2, "Failed to send delay broadcast"

    .line 160
    .line 161
    invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 162
    .line 163
    .line 164
    :goto_1
    return-void

    .line 165
    :pswitch_3
    iget-object v0, p0, LH0/c;->e:Ljava/lang/Object;

    .line 166
    .line 167
    check-cast v0, LA0/o;

    .line 168
    .line 169
    :try_start_2
    invoke-static {}, Lo0/c;->v()Lo0/c;

    .line 170
    .line 171
    .line 172
    move-result-object v1

    .line 173
    invoke-virtual {v1}, Lo0/c;->m()Z

    .line 174
    .line 175
    .line 176
    move-result v1

    .line 177
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 178
    .line 179
    .line 180
    move-result-object v1

    .line 181
    invoke-virtual {v0, v1}, LA0/o;->c(Ljava/lang/Object;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    .line 182
    .line 183
    .line 184
    goto :goto_2

    .line 185
    :catch_2
    move-exception v1

    .line 186
    const-string v3, "FlutterV2rayPlugin"

    .line 187
    .line 188
    const-string v4, "Failed to clear logs"

    .line 189
    .line 190
    invoke-static {v3, v4, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 191
    .line 192
    .line 193
    new-instance v3, Ljava/lang/StringBuilder;

    .line 194
    .line 195
    const-string v4, "Failed to clear logs: "

    .line 196
    .line 197
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 198
    .line 199
    .line 200
    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 201
    .line 202
    .line 203
    move-result-object v1

    .line 204
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 205
    .line 206
    .line 207
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 208
    .line 209
    .line 210
    move-result-object v1

    .line 211
    const-string v3, "LOG_ERROR"

    .line 212
    .line 213
    invoke-virtual {v0, v3, v1, v2}, LA0/o;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 214
    .line 215
    .line 216
    :goto_2
    return-void

    .line 217
    :pswitch_4
    iget-object v0, p0, LH0/c;->e:Ljava/lang/Object;

    .line 218
    .line 219
    check-cast v0, Lio/flutter/plugin/platform/r;

    .line 220
    .line 221
    invoke-virtual {v0, v1}, Lio/flutter/plugin/platform/r;->f(Z)V

    .line 222
    .line 223
    .line 224
    return-void

    .line 225
    :pswitch_5
    iget-object v0, p0, LH0/c;->e:Ljava/lang/Object;

    .line 226
    .line 227
    check-cast v0, Landroidx/appcompat/widget/Toolbar;

    .line 228
    .line 229
    iget-object v0, v0, Landroidx/appcompat/widget/Toolbar;->M:Lh/Q0;

    .line 230
    .line 231
    if-nez v0, :cond_0

    .line 232
    .line 233
    goto :goto_3

    .line 234
    :cond_0
    iget-object v2, v0, Lh/Q0;->e:Lg/k;

    .line 235
    .line 236
    :goto_3
    if-eqz v2, :cond_1

    .line 237
    .line 238
    invoke-virtual {v2}, Lg/k;->collapseActionView()Z

    .line 239
    .line 240
    .line 241
    :cond_1
    return-void

    .line 242
    :pswitch_6
    iget-object v1, p0, LH0/c;->e:Ljava/lang/Object;

    .line 243
    .line 244
    check-cast v1, Landroidx/lifecycle/r;

    .line 245
    .line 246
    const-string v2, "this$0"

    .line 247
    .line 248
    invoke-static {v1, v2}, LT0/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 249
    .line 250
    .line 251
    iget v2, v1, Landroidx/lifecycle/r;->e:I

    .line 252
    .line 253
    iget-object v3, v1, Landroidx/lifecycle/r;->i:Landroidx/lifecycle/n;

    .line 254
    .line 255
    if-nez v2, :cond_2

    .line 256
    .line 257
    iput-boolean v0, v1, Landroidx/lifecycle/r;->f:Z

    .line 258
    .line 259
    sget-object v2, Landroidx/lifecycle/f;->ON_PAUSE:Landroidx/lifecycle/f;

    .line 260
    .line 261
    invoke-virtual {v3, v2}, Landroidx/lifecycle/n;->c(Landroidx/lifecycle/f;)V

    .line 262
    .line 263
    .line 264
    :cond_2
    iget v2, v1, Landroidx/lifecycle/r;->d:I

    .line 265
    .line 266
    if-nez v2, :cond_3

    .line 267
    .line 268
    iget-boolean v2, v1, Landroidx/lifecycle/r;->f:Z

    .line 269
    .line 270
    if-eqz v2, :cond_3

    .line 271
    .line 272
    sget-object v2, Landroidx/lifecycle/f;->ON_STOP:Landroidx/lifecycle/f;

    .line 273
    .line 274
    invoke-virtual {v3, v2}, Landroidx/lifecycle/n;->c(Landroidx/lifecycle/f;)V

    .line 275
    .line 276
    .line 277
    iput-boolean v0, v1, Landroidx/lifecycle/r;->g:Z

    .line 278
    .line 279
    :cond_3
    return-void

    .line 280
    :pswitch_7
    iget-object v0, p0, LH0/c;->e:Ljava/lang/Object;

    .line 281
    .line 282
    check-cast v0, LK/p;

    .line 283
    .line 284
    const-string v2, "fetchFonts result is not OK. ("

    .line 285
    .line 286
    iget-object v3, v0, LK/p;->g:Ljava/lang/Object;

    .line 287
    .line 288
    monitor-enter v3

    .line 289
    :try_start_3
    iget-object v4, v0, LK/p;->k:Li1/a;

    .line 290
    .line 291
    if-nez v4, :cond_4

    .line 292
    .line 293
    monitor-exit v3

    .line 294
    goto/16 :goto_a

    .line 295
    .line 296
    :catchall_0
    move-exception v0

    .line 297
    goto/16 :goto_c

    .line 298
    .line 299
    :cond_4
    monitor-exit v3
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 300
    :try_start_4
    invoke-virtual {v0}, LK/p;->b()Lx/i;

    .line 301
    .line 302
    .line 303
    move-result-object v3

    .line 304
    iget v4, v3, Lx/i;->f:I

    .line 305
    .line 306
    const/4 v5, 0x2

    .line 307
    if-ne v4, v5, :cond_5

    .line 308
    .line 309
    iget-object v5, v0, LK/p;->g:Ljava/lang/Object;

    .line 310
    .line 311
    monitor-enter v5
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 312
    :try_start_5
    monitor-exit v5

    .line 313
    goto :goto_4

    .line 314
    :catchall_1
    move-exception v1

    .line 315
    monitor-exit v5
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 316
    :try_start_6
    throw v1
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    .line 317
    :catchall_2
    move-exception v1

    .line 318
    goto/16 :goto_8

    .line 319
    .line 320
    :cond_5
    :goto_4
    if-nez v4, :cond_8

    .line 321
    .line 322
    :try_start_7
    const-string v2, "EmojiCompat.FontRequestEmojiCompatConfig.buildTypeface"

    .line 323
    .line 324
    sget v4, Lw/c;->a:I

    .line 325
    .line 326
    invoke-static {v2}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 327
    .line 328
    .line 329
    iget-object v2, v0, LK/p;->f:LA/o;

    .line 330
    .line 331
    iget-object v4, v0, LK/p;->d:Landroid/content/Context;

    .line 332
    .line 333
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 334
    .line 335
    .line 336
    filled-new-array {v3}, [Lx/i;

    .line 337
    .line 338
    .line 339
    move-result-object v2

    .line 340
    sget-object v5, Lt/d;->a:Lt/k;

    .line 341
    .line 342
    const-string v5, "TypefaceCompat.createFromFontInfo"

    .line 343
    .line 344
    invoke-static {v5}, Li1/a;->N(Ljava/lang/String;)Ljava/lang/String;

    .line 345
    .line 346
    .line 347
    move-result-object v5

    .line 348
    invoke-static {v5}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_5

    .line 349
    .line 350
    .line 351
    :try_start_8
    sget-object v5, Lt/d;->a:Lt/k;

    .line 352
    .line 353
    invoke-virtual {v5, v4, v2, v1}, Lt/k;->b(Landroid/content/Context;[Lx/i;I)Landroid/graphics/Typeface;

    .line 354
    .line 355
    .line 356
    move-result-object v1
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_6

    .line 357
    :try_start_9
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 358
    .line 359
    .line 360
    iget-object v2, v0, LK/p;->d:Landroid/content/Context;

    .line 361
    .line 362
    iget-object v3, v3, Lx/i;->a:Landroid/net/Uri;

    .line 363
    .line 364
    invoke-static {v2, v3}, Lq/a;->g(Landroid/content/Context;Landroid/net/Uri;)Ljava/nio/MappedByteBuffer;

    .line 365
    .line 366
    .line 367
    move-result-object v2
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_5

    .line 368
    if-eqz v2, :cond_7

    .line 369
    .line 370
    if-eqz v1, :cond_7

    .line 371
    .line 372
    :try_start_a
    const-string v3, "EmojiCompat.MetadataRepo.create"

    .line 373
    .line 374
    invoke-static {v3}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 375
    .line 376
    .line 377
    new-instance v3, LA0/e;

    .line 378
    .line 379
    invoke-static {v2}, La/a;->s(Ljava/nio/MappedByteBuffer;)LL/b;

    .line 380
    .line 381
    .line 382
    move-result-object v2

    .line 383
    invoke-direct {v3, v1, v2}, LA0/e;-><init>(Landroid/graphics/Typeface;LL/b;)V
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_4

    .line 384
    .line 385
    .line 386
    :try_start_b
    invoke-static {}, Landroid/os/Trace;->endSection()V
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_5

    .line 387
    .line 388
    .line 389
    :try_start_c
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 390
    .line 391
    .line 392
    iget-object v1, v0, LK/p;->g:Ljava/lang/Object;

    .line 393
    .line 394
    monitor-enter v1
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_2

    .line 395
    :try_start_d
    iget-object v2, v0, LK/p;->k:Li1/a;

    .line 396
    .line 397
    if-eqz v2, :cond_6

    .line 398
    .line 399
    invoke-virtual {v2, v3}, Li1/a;->x(LA0/e;)V

    .line 400
    .line 401
    .line 402
    goto :goto_5

    .line 403
    :catchall_3
    move-exception v2

    .line 404
    goto :goto_6

    .line 405
    :cond_6
    :goto_5
    monitor-exit v1
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_3

    .line 406
    :try_start_e
    invoke-virtual {v0}, LK/p;->a()V
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_2

    .line 407
    .line 408
    .line 409
    goto :goto_a

    .line 410
    :goto_6
    :try_start_f
    monitor-exit v1
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_3

    .line 411
    :try_start_10
    throw v2
    :try_end_10
    .catchall {:try_start_10 .. :try_end_10} :catchall_2

    .line 412
    :catchall_4
    move-exception v1

    .line 413
    :try_start_11
    sget v2, Lw/c;->a:I

    .line 414
    .line 415
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 416
    .line 417
    .line 418
    throw v1

    .line 419
    :cond_7
    new-instance v1, Ljava/lang/RuntimeException;

    .line 420
    .line 421
    const-string v2, "Unable to open file."

    .line 422
    .line 423
    invoke-direct {v1, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 424
    .line 425
    .line 426
    throw v1

    .line 427
    :catchall_5
    move-exception v1

    .line 428
    goto :goto_7

    .line 429
    :catchall_6
    move-exception v1

    .line 430
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 431
    .line 432
    .line 433
    throw v1
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_5

    .line 434
    :goto_7
    :try_start_12
    sget v2, Lw/c;->a:I

    .line 435
    .line 436
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 437
    .line 438
    .line 439
    throw v1

    .line 440
    :cond_8
    new-instance v1, Ljava/lang/RuntimeException;

    .line 441
    .line 442
    new-instance v3, Ljava/lang/StringBuilder;

    .line 443
    .line 444
    invoke-direct {v3, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 445
    .line 446
    .line 447
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 448
    .line 449
    .line 450
    const-string v2, ")"

    .line 451
    .line 452
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 453
    .line 454
    .line 455
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 456
    .line 457
    .line 458
    move-result-object v2

    .line 459
    invoke-direct {v1, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 460
    .line 461
    .line 462
    throw v1
    :try_end_12
    .catchall {:try_start_12 .. :try_end_12} :catchall_2

    .line 463
    :goto_8
    iget-object v2, v0, LK/p;->g:Ljava/lang/Object;

    .line 464
    .line 465
    monitor-enter v2

    .line 466
    :try_start_13
    iget-object v3, v0, LK/p;->k:Li1/a;

    .line 467
    .line 468
    if-eqz v3, :cond_9

    .line 469
    .line 470
    invoke-virtual {v3, v1}, Li1/a;->w(Ljava/lang/Throwable;)V

    .line 471
    .line 472
    .line 473
    goto :goto_9

    .line 474
    :catchall_7
    move-exception v0

    .line 475
    goto :goto_b

    .line 476
    :cond_9
    :goto_9
    monitor-exit v2
    :try_end_13
    .catchall {:try_start_13 .. :try_end_13} :catchall_7

    .line 477
    invoke-virtual {v0}, LK/p;->a()V

    .line 478
    .line 479
    .line 480
    :goto_a
    return-void

    .line 481
    :goto_b
    :try_start_14
    monitor-exit v2
    :try_end_14
    .catchall {:try_start_14 .. :try_end_14} :catchall_7

    .line 482
    throw v0

    .line 483
    :goto_c
    :try_start_15
    monitor-exit v3
    :try_end_15
    .catchall {:try_start_15 .. :try_end_15} :catchall_0

    .line 484
    throw v0

    .line 485
    :pswitch_8
    iget-object v1, p0, LH0/c;->e:Ljava/lang/Object;

    .line 486
    .line 487
    check-cast v1, LH0/e;

    .line 488
    .line 489
    iget-boolean v3, v1, LH0/e;->j:Z

    .line 490
    .line 491
    if-eqz v3, :cond_a

    .line 492
    .line 493
    goto :goto_e

    .line 494
    :cond_a
    :goto_d
    iget-object v3, v1, LH0/e;->e:Ljava/lang/ref/ReferenceQueue;

    .line 495
    .line 496
    invoke-virtual {v3}, Ljava/lang/ref/ReferenceQueue;->poll()Ljava/lang/ref/Reference;

    .line 497
    .line 498
    .line 499
    move-result-object v3

    .line 500
    check-cast v3, LH0/d;

    .line 501
    .line 502
    if-eqz v3, :cond_c

    .line 503
    .line 504
    iget-object v4, v1, LH0/e;->f:Ljava/util/HashMap;

    .line 505
    .line 506
    instance-of v5, v4, LU0/a;

    .line 507
    .line 508
    if-nez v5, :cond_b

    .line 509
    .line 510
    invoke-virtual {v4, v3}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 511
    .line 512
    .line 513
    move-result-object v3

    .line 514
    check-cast v3, Ljava/lang/Long;

    .line 515
    .line 516
    if-eqz v3, :cond_a

    .line 517
    .line 518
    iget-object v4, v1, LH0/e;->c:Ljava/util/HashMap;

    .line 519
    .line 520
    invoke-virtual {v4, v3}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 521
    .line 522
    .line 523
    iget-object v4, v1, LH0/e;->d:Ljava/util/HashMap;

    .line 524
    .line 525
    invoke-virtual {v4, v3}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 526
    .line 527
    .line 528
    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    .line 529
    .line 530
    .line 531
    move-result-wide v4

    .line 532
    iget-object v6, v1, LH0/e;->a:Lr0/h;

    .line 533
    .line 534
    new-instance v7, LH0/j;

    .line 535
    .line 536
    invoke-direct {v7, v4, v5}, LH0/j;-><init>(J)V

    .line 537
    .line 538
    .line 539
    iget-object v4, v6, Lr0/h;->e:Ljava/lang/Object;

    .line 540
    .line 541
    check-cast v4, LH0/g;

    .line 542
    .line 543
    new-instance v5, LA0/e;

    .line 544
    .line 545
    sget-object v6, LH0/g;->b:LJ0/f;

    .line 546
    .line 547
    invoke-virtual {v6}, LJ0/f;->a()Ljava/lang/Object;

    .line 548
    .line 549
    .line 550
    move-result-object v6

    .line 551
    check-cast v6, LA0/n;

    .line 552
    .line 553
    iget-object v4, v4, LH0/g;->a:LA0/h;

    .line 554
    .line 555
    const-string v8, "dev.flutter.pigeon.webview_flutter_android.PigeonInternalInstanceManager.removeStrongReference"

    .line 556
    .line 557
    invoke-direct {v5, v4, v8, v6, v2}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 558
    .line 559
    .line 560
    invoke-static {v3}, Li1/a;->u(Ljava/lang/Object;)Ljava/util/List;

    .line 561
    .line 562
    .line 563
    move-result-object v3

    .line 564
    new-instance v4, LG0/f;

    .line 565
    .line 566
    invoke-direct {v4, v0, v7}, LG0/f;-><init>(ILjava/lang/Object;)V

    .line 567
    .line 568
    .line 569
    invoke-virtual {v5, v3, v4}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 570
    .line 571
    .line 572
    goto :goto_d

    .line 573
    :cond_b
    const-string v0, "kotlin.collections.MutableMap"

    .line 574
    .line 575
    invoke-static {v4, v0}, LT0/r;->c(Ljava/lang/Object;Ljava/lang/String;)V

    .line 576
    .line 577
    .line 578
    throw v2

    .line 579
    :cond_c
    iget-object v0, v1, LH0/e;->g:Landroid/os/Handler;

    .line 580
    .line 581
    iget-object v2, v1, LH0/e;->h:LH0/c;

    .line 582
    .line 583
    iget-wide v3, v1, LH0/e;->k:J

    .line 584
    .line 585
    invoke-virtual {v0, v2, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 586
    .line 587
    .line 588
    :goto_e
    return-void

    .line 589
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
.end method
