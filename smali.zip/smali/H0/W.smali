.class public final synthetic LH0/W;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LS0/l;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:LH0/Y;

.field public final synthetic f:Landroid/webkit/JsResult;


# direct methods
.method public synthetic constructor <init>(LH0/Y;Landroid/webkit/JsResult;I)V
    .locals 0

    .line 1
    iput p3, p0, LH0/W;->d:I

    iput-object p1, p0, LH0/W;->e:LH0/Y;

    iput-object p2, p0, LH0/W;->f:Landroid/webkit/JsResult;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    iget v0, p0, LH0/W;->d:I

    .line 2
    .line 3
    check-cast p1, LH0/Q;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, LH0/W;->e:LH0/Y;

    .line 9
    .line 10
    iget-boolean v1, p1, LH0/Q;->d:Z

    .line 11
    .line 12
    if-eqz v1, :cond_0

    .line 13
    .line 14
    iget-object v0, v0, LH0/Y;->b:LH0/k;

    .line 15
    .line 16
    iget-object v0, v0, LH0/k;->a:LH0/P;

    .line 17
    .line 18
    iget-object p1, p1, LH0/Q;->c:Ljava/lang/Throwable;

    .line 19
    .line 20
    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    .line 25
    .line 26
    invoke-static {p1}, LH0/P;->b(Ljava/lang/Throwable;)V

    .line 27
    .line 28
    .line 29
    goto :goto_0

    .line 30
    :cond_0
    iget-object p1, p1, LH0/Q;->b:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast p1, Ljava/lang/String;

    .line 33
    .line 34
    iget-object v0, p0, LH0/W;->f:Landroid/webkit/JsResult;

    .line 35
    .line 36
    check-cast v0, Landroid/webkit/JsPromptResult;

    .line 37
    .line 38
    if-eqz p1, :cond_1

    .line 39
    .line 40
    invoke-virtual {v0, p1}, Landroid/webkit/JsPromptResult;->confirm(Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_1
    invoke-virtual {v0}, Landroid/webkit/JsResult;->cancel()V

    .line 45
    .line 46
    .line 47
    :goto_0
    const/4 p1, 0x0

    .line 48
    return-object p1

    .line 49
    :pswitch_0
    iget-object v0, p0, LH0/W;->e:LH0/Y;

    .line 50
    .line 51
    iget-boolean v1, p1, LH0/Q;->d:Z

    .line 52
    .line 53
    if-eqz v1, :cond_2

    .line 54
    .line 55
    iget-object v0, v0, LH0/Y;->b:LH0/k;

    .line 56
    .line 57
    iget-object v0, v0, LH0/k;->a:LH0/P;

    .line 58
    .line 59
    iget-object p1, p1, LH0/Q;->c:Ljava/lang/Throwable;

    .line 60
    .line 61
    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 65
    .line 66
    .line 67
    invoke-static {p1}, LH0/P;->b(Ljava/lang/Throwable;)V

    .line 68
    .line 69
    .line 70
    goto :goto_1

    .line 71
    :cond_2
    iget-object p1, p0, LH0/W;->f:Landroid/webkit/JsResult;

    .line 72
    .line 73
    invoke-virtual {p1}, Landroid/webkit/JsResult;->confirm()V

    .line 74
    .line 75
    .line 76
    :goto_1
    const/4 p1, 0x0

    .line 77
    return-object p1

    .line 78
    :pswitch_1
    iget-object v0, p0, LH0/W;->e:LH0/Y;

    .line 79
    .line 80
    iget-boolean v1, p1, LH0/Q;->d:Z

    .line 81
    .line 82
    if-eqz v1, :cond_3

    .line 83
    .line 84
    iget-object v0, v0, LH0/Y;->b:LH0/k;

    .line 85
    .line 86
    iget-object v0, v0, LH0/k;->a:LH0/P;

    .line 87
    .line 88
    iget-object p1, p1, LH0/Q;->c:Ljava/lang/Throwable;

    .line 89
    .line 90
    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 94
    .line 95
    .line 96
    invoke-static {p1}, LH0/P;->b(Ljava/lang/Throwable;)V

    .line 97
    .line 98
    .line 99
    goto :goto_2

    .line 100
    :cond_3
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 101
    .line 102
    iget-object p1, p1, LH0/Q;->b:Ljava/lang/Object;

    .line 103
    .line 104
    invoke-virtual {v0, p1}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    .line 105
    .line 106
    .line 107
    move-result p1

    .line 108
    iget-object v0, p0, LH0/W;->f:Landroid/webkit/JsResult;

    .line 109
    .line 110
    if-eqz p1, :cond_4

    .line 111
    .line 112
    invoke-virtual {v0}, Landroid/webkit/JsResult;->confirm()V

    .line 113
    .line 114
    .line 115
    goto :goto_2

    .line 116
    :cond_4
    invoke-virtual {v0}, Landroid/webkit/JsResult;->cancel()V

    .line 117
    .line 118
    .line 119
    :goto_2
    const/4 p1, 0x0

    .line 120
    return-object p1

    .line 121
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
.end method
