.class public final synthetic LH0/e0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic d:LH0/f0;

.field public final synthetic e:Landroid/webkit/WebView;

.field public final synthetic f:F

.field public final synthetic g:F


# direct methods
.method public synthetic constructor <init>(LH0/f0;Landroid/webkit/WebView;FF)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LH0/e0;->d:LH0/f0;

    iput-object p2, p0, LH0/e0;->e:Landroid/webkit/WebView;

    iput p3, p0, LH0/e0;->f:F

    iput p4, p0, LH0/e0;->g:F

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 12

    .line 1
    iget v0, p0, LH0/e0;->f:F

    .line 2
    .line 3
    float-to-double v0, v0

    .line 4
    iget v2, p0, LH0/e0;->g:F

    .line 5
    .line 6
    float-to-double v2, v2

    .line 7
    new-instance v4, LH0/r;

    .line 8
    .line 9
    const/4 v5, 0x2

    .line 10
    invoke-direct {v4, v5}, LH0/r;-><init>(I)V

    .line 11
    .line 12
    .line 13
    iget-object v5, p0, LH0/e0;->d:LH0/f0;

    .line 14
    .line 15
    iget-object v6, v5, LH0/f0;->a:LH0/o;

    .line 16
    .line 17
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    .line 19
    .line 20
    iget-object v7, p0, LH0/e0;->e:Landroid/webkit/WebView;

    .line 21
    .line 22
    const-string v8, "viewArg"

    .line 23
    .line 24
    invoke-static {v7, v8}, LT0/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    iget-object v6, v6, LH0/o;->a:LH0/P;

    .line 28
    .line 29
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 30
    .line 31
    .line 32
    iget-object v8, v6, LH0/P;->b:LH0/e;

    .line 33
    .line 34
    invoke-virtual {v8, v5}, LH0/e;->d(Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v8

    .line 38
    if-nez v8, :cond_0

    .line 39
    .line 40
    const-string v0, ""

    .line 41
    .line 42
    const-string v1, "missing-instance-error"

    .line 43
    .line 44
    const-string v2, "Callback to `WebViewClient.onScaleChanged` failed because native instance was not in the instance manager."

    .line 45
    .line 46
    invoke-static {v1, v2, v0}, LF0/f;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    return-void

    .line 50
    :cond_0
    invoke-virtual {v6}, LH0/P;->a()LA0/n;

    .line 51
    .line 52
    .line 53
    move-result-object v8

    .line 54
    new-instance v9, LA0/e;

    .line 55
    .line 56
    const-string v10, "dev.flutter.pigeon.webview_flutter_android.WebViewClient.onScaleChanged"

    .line 57
    .line 58
    const/4 v11, 0x0

    .line 59
    iget-object v6, v6, LH0/P;->a:LA0/h;

    .line 60
    .line 61
    invoke-direct {v9, v6, v10, v8, v11}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 62
    .line 63
    .line 64
    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 69
    .line 70
    .line 71
    move-result-object v1

    .line 72
    filled-new-array {v5, v7, v0, v1}, [Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    invoke-static {v0}, LK0/e;->R([Ljava/lang/Object;)Ljava/util/List;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    new-instance v1, LH0/N;

    .line 81
    .line 82
    const/4 v2, 0x5

    .line 83
    invoke-direct {v1, v2, v4}, LH0/N;-><init>(ILjava/lang/Object;)V

    .line 84
    .line 85
    .line 86
    invoke-virtual {v9, v0, v1}, LA0/e;->e(Ljava/lang/Object;LA0/d;)V

    .line 87
    .line 88
    .line 89
    return-void
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
.end method
