.class public interface abstract LF0/h;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LF0/g;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    sget-object v0, LF0/g;->a:LF0/g;

    .line 2
    .line 3
    sput-object v0, LF0/h;->a:LF0/g;

    .line 4
    .line 5
    return-void
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
.end method


# virtual methods
.method public abstract a(Ljava/util/List;LF0/i;)V
.end method

.method public abstract c(Ljava/util/List;LF0/i;)Ljava/util/List;
.end method

.method public abstract d(Ljava/util/List;LF0/i;)Ljava/util/Map;
.end method

.method public abstract e(Ljava/lang/String;Ljava/lang/String;LF0/i;)V
.end method

.method public abstract f(Ljava/lang/String;LF0/i;)LF0/Q;
.end method

.method public abstract g(Ljava/lang/String;LF0/i;)Ljava/lang/Boolean;
.end method

.method public abstract i(Ljava/lang/String;JLF0/i;)V
.end method

.method public abstract j(Ljava/lang/String;LF0/i;)Ljava/lang/String;
.end method

.method public abstract k(Ljava/lang/String;ZLF0/i;)V
.end method

.method public abstract l(Ljava/lang/String;LF0/i;)Ljava/lang/Double;
.end method

.method public abstract n(Ljava/lang/String;LF0/i;)Ljava/lang/Long;
.end method

.method public abstract o(Ljava/lang/String;LF0/i;)Ljava/util/ArrayList;
.end method

.method public abstract q(Ljava/lang/String;Ljava/util/List;LF0/i;)V
.end method

.method public abstract r(Ljava/lang/String;DLF0/i;)V
.end method

.method public abstract s(Ljava/lang/String;Ljava/lang/String;LF0/i;)V
.end method
