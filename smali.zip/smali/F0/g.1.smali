.class public final LF0/g;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final synthetic a:LF0/g;

.field public static final b:LJ0/f;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LF0/g;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LF0/g;->a:LF0/g;

    .line 7
    .line 8
    new-instance v0, LF0/e;

    .line 9
    .line 10
    const/4 v1, 0x0

    .line 11
    invoke-direct {v0, v1}, LF0/e;-><init>(I)V

    .line 12
    .line 13
    .line 14
    new-instance v1, LJ0/f;

    .line 15
    .line 16
    invoke-direct {v1, v0}, LJ0/f;-><init>(LS0/a;)V

    .line 17
    .line 18
    .line 19
    sput-object v1, LF0/g;->b:LJ0/f;

    .line 20
    .line 21
    return-void
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
.end method

.method public static a()LA0/n;
    .locals 1

    .line 1
    sget-object v0, LF0/g;->b:LJ0/f;

    .line 2
    .line 3
    invoke-virtual {v0}, LJ0/f;->a()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, LA0/n;

    .line 8
    .line 9
    return-object v0
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
.end method

.method public static b(LA0/h;LF0/h;Ljava/lang/String;)V
    .locals 5

    .line 1
    const-string v0, "binaryMessenger"

    .line 2
    .line 3
    invoke-static {p0, v0}, LT0/h;->e(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-lez v0, :cond_0

    .line 11
    .line 12
    const-string v0, "."

    .line 13
    .line 14
    invoke-virtual {v0, p2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object p2

    .line 18
    goto :goto_0

    .line 19
    :cond_0
    const-string p2, ""

    .line 20
    .line 21
    :goto_0
    new-instance v0, LA0/m;

    .line 22
    .line 23
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 24
    .line 25
    .line 26
    invoke-interface {p0, v0}, LA0/h;->q(LA0/m;)LO/k;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    new-instance v1, LA0/e;

    .line 31
    .line 32
    const-string v2, "dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.setBool"

    .line 33
    .line 34
    invoke-static {v2, p2}, LF0/f;->g(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v2

    .line 38
    invoke-static {}, LF0/g;->a()LA0/n;

    .line 39
    .line 40
    .line 41
    move-result-object v3

    .line 42
    invoke-direct {v1, p0, v2, v3, v0}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 43
    .line 44
    .line 45
    const/4 v2, 0x0

    .line 46
    if-eqz p1, :cond_1

    .line 47
    .line 48
    new-instance v3, LF0/d;

    .line 49
    .line 50
    const/4 v4, 0x7

    .line 51
    invoke-direct {v3, p1, v4}, LF0/d;-><init>(LF0/h;I)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {v1, v3}, LA0/e;->f(LA0/c;)V

    .line 55
    .line 56
    .line 57
    goto :goto_1

    .line 58
    :cond_1
    invoke-virtual {v1, v2}, LA0/e;->f(LA0/c;)V

    .line 59
    .line 60
    .line 61
    :goto_1
    new-instance v1, LA0/e;

    .line 62
    .line 63
    const-string v3, "dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.setString"

    .line 64
    .line 65
    invoke-static {v3, p2}, LF0/f;->g(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v3

    .line 69
    invoke-static {}, LF0/g;->a()LA0/n;

    .line 70
    .line 71
    .line 72
    move-result-object v4

    .line 73
    invoke-direct {v1, p0, v3, v4, v0}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 74
    .line 75
    .line 76
    if-eqz p1, :cond_2

    .line 77
    .line 78
    new-instance v3, LF0/d;

    .line 79
    .line 80
    const/16 v4, 0xd

    .line 81
    .line 82
    invoke-direct {v3, p1, v4}, LF0/d;-><init>(LF0/h;I)V

    .line 83
    .line 84
    .line 85
    invoke-virtual {v1, v3}, LA0/e;->f(LA0/c;)V

    .line 86
    .line 87
    .line 88
    goto :goto_2

    .line 89
    :cond_2
    invoke-virtual {v1, v2}, LA0/e;->f(LA0/c;)V

    .line 90
    .line 91
    .line 92
    :goto_2
    new-instance v1, LA0/e;

    .line 93
    .line 94
    const-string v3, "dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.setInt"

    .line 95
    .line 96
    invoke-static {v3, p2}, LF0/f;->g(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 97
    .line 98
    .line 99
    move-result-object v3

    .line 100
    invoke-static {}, LF0/g;->a()LA0/n;

    .line 101
    .line 102
    .line 103
    move-result-object v4

    .line 104
    invoke-direct {v1, p0, v3, v4, v0}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 105
    .line 106
    .line 107
    if-eqz p1, :cond_3

    .line 108
    .line 109
    new-instance v3, LF0/d;

    .line 110
    .line 111
    const/16 v4, 0xe

    .line 112
    .line 113
    invoke-direct {v3, p1, v4}, LF0/d;-><init>(LF0/h;I)V

    .line 114
    .line 115
    .line 116
    invoke-virtual {v1, v3}, LA0/e;->f(LA0/c;)V

    .line 117
    .line 118
    .line 119
    goto :goto_3

    .line 120
    :cond_3
    invoke-virtual {v1, v2}, LA0/e;->f(LA0/c;)V

    .line 121
    .line 122
    .line 123
    :goto_3
    new-instance v1, LA0/e;

    .line 124
    .line 125
    const-string v3, "dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.setDouble"

    .line 126
    .line 127
    invoke-static {v3, p2}, LF0/f;->g(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 128
    .line 129
    .line 130
    move-result-object v3

    .line 131
    invoke-static {}, LF0/g;->a()LA0/n;

    .line 132
    .line 133
    .line 134
    move-result-object v4

    .line 135
    invoke-direct {v1, p0, v3, v4, v0}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 136
    .line 137
    .line 138
    if-eqz p1, :cond_4

    .line 139
    .line 140
    new-instance v3, LF0/d;

    .line 141
    .line 142
    const/4 v4, 0x0

    .line 143
    invoke-direct {v3, p1, v4}, LF0/d;-><init>(LF0/h;I)V

    .line 144
    .line 145
    .line 146
    invoke-virtual {v1, v3}, LA0/e;->f(LA0/c;)V

    .line 147
    .line 148
    .line 149
    goto :goto_4

    .line 150
    :cond_4
    invoke-virtual {v1, v2}, LA0/e;->f(LA0/c;)V

    .line 151
    .line 152
    .line 153
    :goto_4
    new-instance v1, LA0/e;

    .line 154
    .line 155
    const-string v3, "dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.setEncodedStringList"

    .line 156
    .line 157
    invoke-static {v3, p2}, LF0/f;->g(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object v3

    .line 161
    invoke-static {}, LF0/g;->a()LA0/n;

    .line 162
    .line 163
    .line 164
    move-result-object v4

    .line 165
    invoke-direct {v1, p0, v3, v4, v0}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 166
    .line 167
    .line 168
    if-eqz p1, :cond_5

    .line 169
    .line 170
    new-instance v3, LF0/d;

    .line 171
    .line 172
    const/4 v4, 0x1

    .line 173
    invoke-direct {v3, p1, v4}, LF0/d;-><init>(LF0/h;I)V

    .line 174
    .line 175
    .line 176
    invoke-virtual {v1, v3}, LA0/e;->f(LA0/c;)V

    .line 177
    .line 178
    .line 179
    goto :goto_5

    .line 180
    :cond_5
    invoke-virtual {v1, v2}, LA0/e;->f(LA0/c;)V

    .line 181
    .line 182
    .line 183
    :goto_5
    new-instance v1, LA0/e;

    .line 184
    .line 185
    const-string v3, "dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.setDeprecatedStringList"

    .line 186
    .line 187
    invoke-static {v3, p2}, LF0/f;->g(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 188
    .line 189
    .line 190
    move-result-object v3

    .line 191
    invoke-static {}, LF0/g;->a()LA0/n;

    .line 192
    .line 193
    .line 194
    move-result-object v4

    .line 195
    invoke-direct {v1, p0, v3, v4, v0}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 196
    .line 197
    .line 198
    if-eqz p1, :cond_6

    .line 199
    .line 200
    new-instance v3, LF0/d;

    .line 201
    .line 202
    const/4 v4, 0x2

    .line 203
    invoke-direct {v3, p1, v4}, LF0/d;-><init>(LF0/h;I)V

    .line 204
    .line 205
    .line 206
    invoke-virtual {v1, v3}, LA0/e;->f(LA0/c;)V

    .line 207
    .line 208
    .line 209
    goto :goto_6

    .line 210
    :cond_6
    invoke-virtual {v1, v2}, LA0/e;->f(LA0/c;)V

    .line 211
    .line 212
    .line 213
    :goto_6
    new-instance v1, LA0/e;

    .line 214
    .line 215
    const-string v3, "dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.getString"

    .line 216
    .line 217
    invoke-static {v3, p2}, LF0/f;->g(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 218
    .line 219
    .line 220
    move-result-object v3

    .line 221
    invoke-static {}, LF0/g;->a()LA0/n;

    .line 222
    .line 223
    .line 224
    move-result-object v4

    .line 225
    invoke-direct {v1, p0, v3, v4, v0}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 226
    .line 227
    .line 228
    if-eqz p1, :cond_7

    .line 229
    .line 230
    new-instance v3, LF0/d;

    .line 231
    .line 232
    const/4 v4, 0x3

    .line 233
    invoke-direct {v3, p1, v4}, LF0/d;-><init>(LF0/h;I)V

    .line 234
    .line 235
    .line 236
    invoke-virtual {v1, v3}, LA0/e;->f(LA0/c;)V

    .line 237
    .line 238
    .line 239
    goto :goto_7

    .line 240
    :cond_7
    invoke-virtual {v1, v2}, LA0/e;->f(LA0/c;)V

    .line 241
    .line 242
    .line 243
    :goto_7
    new-instance v1, LA0/e;

    .line 244
    .line 245
    const-string v3, "dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.getBool"

    .line 246
    .line 247
    invoke-static {v3, p2}, LF0/f;->g(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 248
    .line 249
    .line 250
    move-result-object v3

    .line 251
    invoke-static {}, LF0/g;->a()LA0/n;

    .line 252
    .line 253
    .line 254
    move-result-object v4

    .line 255
    invoke-direct {v1, p0, v3, v4, v0}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 256
    .line 257
    .line 258
    if-eqz p1, :cond_8

    .line 259
    .line 260
    new-instance v3, LF0/d;

    .line 261
    .line 262
    const/4 v4, 0x4

    .line 263
    invoke-direct {v3, p1, v4}, LF0/d;-><init>(LF0/h;I)V

    .line 264
    .line 265
    .line 266
    invoke-virtual {v1, v3}, LA0/e;->f(LA0/c;)V

    .line 267
    .line 268
    .line 269
    goto :goto_8

    .line 270
    :cond_8
    invoke-virtual {v1, v2}, LA0/e;->f(LA0/c;)V

    .line 271
    .line 272
    .line 273
    :goto_8
    new-instance v1, LA0/e;

    .line 274
    .line 275
    const-string v3, "dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.getDouble"

    .line 276
    .line 277
    invoke-static {v3, p2}, LF0/f;->g(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 278
    .line 279
    .line 280
    move-result-object v3

    .line 281
    invoke-static {}, LF0/g;->a()LA0/n;

    .line 282
    .line 283
    .line 284
    move-result-object v4

    .line 285
    invoke-direct {v1, p0, v3, v4, v0}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 286
    .line 287
    .line 288
    if-eqz p1, :cond_9

    .line 289
    .line 290
    new-instance v3, LF0/d;

    .line 291
    .line 292
    const/4 v4, 0x5

    .line 293
    invoke-direct {v3, p1, v4}, LF0/d;-><init>(LF0/h;I)V

    .line 294
    .line 295
    .line 296
    invoke-virtual {v1, v3}, LA0/e;->f(LA0/c;)V

    .line 297
    .line 298
    .line 299
    goto :goto_9

    .line 300
    :cond_9
    invoke-virtual {v1, v2}, LA0/e;->f(LA0/c;)V

    .line 301
    .line 302
    .line 303
    :goto_9
    new-instance v1, LA0/e;

    .line 304
    .line 305
    const-string v3, "dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.getInt"

    .line 306
    .line 307
    invoke-static {v3, p2}, LF0/f;->g(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 308
    .line 309
    .line 310
    move-result-object v3

    .line 311
    invoke-static {}, LF0/g;->a()LA0/n;

    .line 312
    .line 313
    .line 314
    move-result-object v4

    .line 315
    invoke-direct {v1, p0, v3, v4, v0}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 316
    .line 317
    .line 318
    if-eqz p1, :cond_a

    .line 319
    .line 320
    new-instance v3, LF0/d;

    .line 321
    .line 322
    const/4 v4, 0x6

    .line 323
    invoke-direct {v3, p1, v4}, LF0/d;-><init>(LF0/h;I)V

    .line 324
    .line 325
    .line 326
    invoke-virtual {v1, v3}, LA0/e;->f(LA0/c;)V

    .line 327
    .line 328
    .line 329
    goto :goto_a

    .line 330
    :cond_a
    invoke-virtual {v1, v2}, LA0/e;->f(LA0/c;)V

    .line 331
    .line 332
    .line 333
    :goto_a
    new-instance v1, LA0/e;

    .line 334
    .line 335
    const-string v3, "dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.getPlatformEncodedStringList"

    .line 336
    .line 337
    invoke-static {v3, p2}, LF0/f;->g(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 338
    .line 339
    .line 340
    move-result-object v3

    .line 341
    invoke-static {}, LF0/g;->a()LA0/n;

    .line 342
    .line 343
    .line 344
    move-result-object v4

    .line 345
    invoke-direct {v1, p0, v3, v4, v0}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 346
    .line 347
    .line 348
    if-eqz p1, :cond_b

    .line 349
    .line 350
    new-instance v3, LF0/d;

    .line 351
    .line 352
    const/16 v4, 0x8

    .line 353
    .line 354
    invoke-direct {v3, p1, v4}, LF0/d;-><init>(LF0/h;I)V

    .line 355
    .line 356
    .line 357
    invoke-virtual {v1, v3}, LA0/e;->f(LA0/c;)V

    .line 358
    .line 359
    .line 360
    goto :goto_b

    .line 361
    :cond_b
    invoke-virtual {v1, v2}, LA0/e;->f(LA0/c;)V

    .line 362
    .line 363
    .line 364
    :goto_b
    new-instance v1, LA0/e;

    .line 365
    .line 366
    const-string v3, "dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.getStringList"

    .line 367
    .line 368
    invoke-static {v3, p2}, LF0/f;->g(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 369
    .line 370
    .line 371
    move-result-object v3

    .line 372
    invoke-static {}, LF0/g;->a()LA0/n;

    .line 373
    .line 374
    .line 375
    move-result-object v4

    .line 376
    invoke-direct {v1, p0, v3, v4, v0}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 377
    .line 378
    .line 379
    if-eqz p1, :cond_c

    .line 380
    .line 381
    new-instance v3, LF0/d;

    .line 382
    .line 383
    const/16 v4, 0x9

    .line 384
    .line 385
    invoke-direct {v3, p1, v4}, LF0/d;-><init>(LF0/h;I)V

    .line 386
    .line 387
    .line 388
    invoke-virtual {v1, v3}, LA0/e;->f(LA0/c;)V

    .line 389
    .line 390
    .line 391
    goto :goto_c

    .line 392
    :cond_c
    invoke-virtual {v1, v2}, LA0/e;->f(LA0/c;)V

    .line 393
    .line 394
    .line 395
    :goto_c
    new-instance v1, LA0/e;

    .line 396
    .line 397
    const-string v3, "dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.clear"

    .line 398
    .line 399
    invoke-static {v3, p2}, LF0/f;->g(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 400
    .line 401
    .line 402
    move-result-object v3

    .line 403
    invoke-static {}, LF0/g;->a()LA0/n;

    .line 404
    .line 405
    .line 406
    move-result-object v4

    .line 407
    invoke-direct {v1, p0, v3, v4, v0}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 408
    .line 409
    .line 410
    if-eqz p1, :cond_d

    .line 411
    .line 412
    new-instance v3, LF0/d;

    .line 413
    .line 414
    const/16 v4, 0xa

    .line 415
    .line 416
    invoke-direct {v3, p1, v4}, LF0/d;-><init>(LF0/h;I)V

    .line 417
    .line 418
    .line 419
    invoke-virtual {v1, v3}, LA0/e;->f(LA0/c;)V

    .line 420
    .line 421
    .line 422
    goto :goto_d

    .line 423
    :cond_d
    invoke-virtual {v1, v2}, LA0/e;->f(LA0/c;)V

    .line 424
    .line 425
    .line 426
    :goto_d
    new-instance v1, LA0/e;

    .line 427
    .line 428
    const-string v3, "dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.getAll"

    .line 429
    .line 430
    invoke-static {v3, p2}, LF0/f;->g(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 431
    .line 432
    .line 433
    move-result-object v3

    .line 434
    invoke-static {}, LF0/g;->a()LA0/n;

    .line 435
    .line 436
    .line 437
    move-result-object v4

    .line 438
    invoke-direct {v1, p0, v3, v4, v0}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 439
    .line 440
    .line 441
    if-eqz p1, :cond_e

    .line 442
    .line 443
    new-instance v3, LF0/d;

    .line 444
    .line 445
    const/16 v4, 0xb

    .line 446
    .line 447
    invoke-direct {v3, p1, v4}, LF0/d;-><init>(LF0/h;I)V

    .line 448
    .line 449
    .line 450
    invoke-virtual {v1, v3}, LA0/e;->f(LA0/c;)V

    .line 451
    .line 452
    .line 453
    goto :goto_e

    .line 454
    :cond_e
    invoke-virtual {v1, v2}, LA0/e;->f(LA0/c;)V

    .line 455
    .line 456
    .line 457
    :goto_e
    new-instance v1, LA0/e;

    .line 458
    .line 459
    const-string v3, "dev.flutter.pigeon.shared_preferences_android.SharedPreferencesAsyncApi.getKeys"

    .line 460
    .line 461
    invoke-static {v3, p2}, LF0/f;->g(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 462
    .line 463
    .line 464
    move-result-object p2

    .line 465
    invoke-static {}, LF0/g;->a()LA0/n;

    .line 466
    .line 467
    .line 468
    move-result-object v3

    .line 469
    invoke-direct {v1, p0, p2, v3, v0}, LA0/e;-><init>(LA0/h;Ljava/lang/String;LA0/n;LO/k;)V

    .line 470
    .line 471
    .line 472
    if-eqz p1, :cond_f

    .line 473
    .line 474
    new-instance p0, LF0/d;

    .line 475
    .line 476
    const/16 p2, 0xc

    .line 477
    .line 478
    invoke-direct {p0, p1, p2}, LF0/d;-><init>(LF0/h;I)V

    .line 479
    .line 480
    .line 481
    invoke-virtual {v1, p0}, LA0/e;->f(LA0/c;)V

    .line 482
    .line 483
    .line 484
    return-void

    .line 485
    :cond_f
    invoke-virtual {v1, v2}, LA0/e;->f(LA0/c;)V

    .line 486
    .line 487
    .line 488
    return-void
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
.end method
