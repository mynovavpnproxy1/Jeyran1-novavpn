.class public interface abstract LK/i;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract u(Li1/a;)V
.end method
