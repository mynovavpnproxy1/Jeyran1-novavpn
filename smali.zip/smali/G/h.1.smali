.class public interface abstract LG/h;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract getData()Lc1/d;
.end method

.method public abstract j(LS0/p;LN0/h;)Ljava/lang/Object;
.end method
