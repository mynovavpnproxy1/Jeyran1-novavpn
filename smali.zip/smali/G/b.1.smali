.class public final LG/b;
.super Ljava/io/IOException;
.source "SourceFile"
