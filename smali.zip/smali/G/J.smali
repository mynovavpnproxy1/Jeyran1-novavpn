.class public final LG/J;
.super LT0/i;
.source "SourceFile"

# interfaces
.implements LS0/l;


# instance fields
.field public final synthetic e:I

.field public final synthetic f:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LG/J;->e:I

    iput-object p2, p0, LG/J;->f:Ljava/lang/Object;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, LT0/i;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    .line 1
    iget v0, p0, LG/J;->e:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Ljava/lang/Throwable;

    .line 7
    .line 8
    iget-object p1, p0, LG/J;->f:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast p1, Lh1/h;

    .line 11
    .line 12
    invoke-virtual {p1}, Lh1/h;->b()V

    .line 13
    .line 14
    .line 15
    sget-object p1, LJ0/h;->a:LJ0/h;

    .line 16
    .line 17
    return-object p1

    .line 18
    :pswitch_0
    check-cast p1, Ljava/lang/Throwable;

    .line 19
    .line 20
    sget-object p1, LJ0/h;->a:LJ0/h;

    .line 21
    .line 22
    iget-object v0, p0, LG/J;->f:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v0, LZ0/f;

    .line 25
    .line 26
    invoke-virtual {v0, p1}, LZ0/f;->l(Ljava/lang/Object;)V

    .line 27
    .line 28
    .line 29
    return-object p1

    .line 30
    :pswitch_1
    check-cast p1, Ljava/lang/Throwable;

    .line 31
    .line 32
    iget-object v0, p0, LG/J;->f:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast v0, LG/N;

    .line 35
    .line 36
    if-eqz p1, :cond_0

    .line 37
    .line 38
    iget-object v1, v0, LG/N;->k:Lo0/c;

    .line 39
    .line 40
    new-instance v2, LG/Z;

    .line 41
    .line 42
    invoke-direct {v2, p1}, LG/Z;-><init>(Ljava/lang/Throwable;)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {v1, v2}, Lo0/c;->E(LG/i0;)V

    .line 46
    .line 47
    .line 48
    :cond_0
    iget-object p1, v0, LG/N;->m:LJ0/f;

    .line 49
    .line 50
    iget-object p1, p1, LJ0/f;->e:Ljava/lang/Object;

    .line 51
    .line 52
    sget-object v1, LJ0/g;->a:LJ0/g;

    .line 53
    .line 54
    if-eq p1, v1, :cond_1

    .line 55
    .line 56
    iget-object p1, v0, LG/N;->m:LJ0/f;

    .line 57
    .line 58
    invoke-virtual {p1}, LJ0/f;->a()Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object p1

    .line 62
    check-cast p1, LG/W;

    .line 63
    .line 64
    invoke-virtual {p1}, LG/W;->close()V

    .line 65
    .line 66
    .line 67
    :cond_1
    sget-object p1, LJ0/h;->a:LJ0/h;

    .line 68
    .line 69
    return-object p1

    .line 70
    nop

    .line 71
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
.end method
