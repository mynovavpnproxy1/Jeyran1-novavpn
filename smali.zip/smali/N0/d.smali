.class public interface abstract LN0/d;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract f()LN0/d;
.end method
