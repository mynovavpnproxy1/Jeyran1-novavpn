.class public interface abstract LO/e;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract d(ILjava/io/Serializable;)V
.end method

.method public abstract g()V
.end method
