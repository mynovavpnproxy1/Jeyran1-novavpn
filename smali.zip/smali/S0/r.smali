.class public interface abstract LS0/r;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LJ0/a;
