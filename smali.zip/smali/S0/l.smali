.class public interface abstract LS0/l;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LJ0/a;


# virtual methods
.method public abstract h(Ljava/lang/Object;)Ljava/lang/Object;
.end method
