.class public interface abstract LS0/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LJ0/a;


# virtual methods
.method public abstract c()Ljava/lang/Object;
.end method
