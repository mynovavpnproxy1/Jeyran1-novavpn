.class public interface abstract LS0/s;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LJ0/a;
