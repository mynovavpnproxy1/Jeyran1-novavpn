.class public interface abstract LS0/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LJ0/a;
