.class public interface abstract LS0/n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LJ0/a;
