.class public interface abstract LS0/p;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LJ0/a;


# virtual methods
.method public abstract e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method
