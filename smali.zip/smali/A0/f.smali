.class public interface abstract LA0/f;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract b(Ljava/nio/ByteBuffer;Ls0/g;)V
.end method
