.class public interface abstract LA0/d;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract c(Ljava/lang/Object;)V
.end method
