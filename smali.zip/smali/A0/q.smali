.class public interface abstract LA0/q;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Ljava/lang/Object;)Ljava/nio/ByteBuffer;
.end method

.method public abstract b(Ljava/nio/ByteBuffer;)LA0/a;
.end method

.method public abstract c(Ljava/nio/ByteBuffer;)Ljava/lang/Object;
.end method

.method public abstract d(LA0/a;)Ljava/nio/ByteBuffer;
.end method

.method public abstract e(Ljava/lang/String;Ljava/lang/String;)Ljava/nio/ByteBuffer;
.end method

.method public abstract f(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)Ljava/nio/ByteBuffer;
.end method
