.class public interface abstract LA0/p;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract f(LA0/a;LA0/o;)V
.end method
