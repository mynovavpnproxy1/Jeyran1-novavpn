.class public interface abstract LA0/h;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract b(Ljava/lang/String;Ljava/nio/ByteBuffer;)V
.end method

.method public abstract d(Ljava/lang/String;LA0/f;LO/k;)V
.end method

.method public abstract f(Ljava/lang/String;Ljava/nio/ByteBuffer;LA0/g;)V
.end method

.method public abstract g(Ljava/lang/String;LA0/f;)V
.end method

.method public abstract q(LA0/m;)LO/k;
.end method
