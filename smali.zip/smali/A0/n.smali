.class public interface abstract LA0/n;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Ljava/nio/ByteBuffer;)Ljava/lang/Object;
.end method

.method public abstract b(Ljava/lang/Object;)Ljava/nio/ByteBuffer;
.end method
