.class public interface abstract LI0/b;
.super Ljava/lang/Object;
.source "SourceFile"
