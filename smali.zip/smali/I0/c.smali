.class public interface abstract LI0/c;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Landroid/view/View;)Z
.end method
