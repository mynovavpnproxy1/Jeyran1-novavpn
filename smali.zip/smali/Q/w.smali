.class public abstract LQ/w;
.super Ljava/lang/Object;
.source "SourceFile"
