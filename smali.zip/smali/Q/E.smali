.class public abstract LQ/E;
.super Ljava/lang/Object;
.source "SourceFile"
